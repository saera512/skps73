import React, { useState, useEffect } from 'react';
import {
  Murid,
  ItemAktiviti,
  ModAktiviti,
  RekodPembelajaran,
  LencanaPencapaian,
} from './types';
import {
  SENARAI_KEMAHIRAN,
  DATA_SOALAN_AKTIVITI,
  MURID_LALAI,
  SENARAI_LENCANA,
} from './data/kemahiranData';
import { AktivitiSusunSukuKata } from './components/AktivitiSusunSukuKata';
import { AktivitiSusunHuruf } from './components/AktivitiSusunHuruf';
import { AktivitiMenulisAsas } from './components/AktivitiMenulisAsas';
import { AktivitiPadananGambar } from './components/AktivitiPadananGambar';
import { DashboardGuru } from './components/DashboardGuru';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';
import { bunyi } from './utils/soundEngine';
import {
  BookOpen,
  LayoutGrid,
  PenTool,
  Puzzle,
  LineChart,
  User,
  Star,
  Award,
  ChevronRight,
  Sparkles,
  Volume2,
  HelpCircle,
} from 'lucide-react';

const STORAGE_KEY_MURID = 'celik_minda_senarai_murid';
const STORAGE_KEY_REKOD = 'celik_minda_rekod_pembelajaran';
const STORAGE_KEY_MURID_AKTIF = 'celik_minda_murid_aktif_id';

export default function App() {
  // Pengurusan Senarai Murid
  const [senaraiMurid, setSenaraiMurid] = useState<Murid[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_MURID);
      if (saved) return JSON.parse(saved);
    } catch {
      // Guna lalai
    }
    return MURID_LALAI;
  });

  // Murid Aktif Semasa di Peranti
  const [muridAktif, setMuridAktif] = useState<Murid>(() => {
    try {
      const savedId = localStorage.getItem(STORAGE_KEY_MURID_AKTIF);
      if (savedId) {
        const jumpa = senaraiMurid.find((m) => m.id === savedId);
        if (jumpa) return jumpa;
      }
    } catch {
      // Guna murid pertama
    }
    return senaraiMurid[0] || MURID_LALAI[0];
  });

  // Rekod Pembelajaran Automatik
  const [senaraiRekod, setSenaraiRekod] = useState<RekodPembelajaran[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_REKOD);
      if (saved) return JSON.parse(saved);
    } catch {
      // Lalai
    }
    // Cipta beberapa rekod awal supaya papan pemuka analitik masa nyata ada data pemula
    return [
      {
        id: 'rekod-p1',
        muridId: 'm1',
        namaMurid: 'Muhammad Amirul bin Razali',
        kelas: '2 Amanah',
        kemahiranId: 'K4_PERKATAAN_KVKV',
        namaKemahiran: 'Susun Suku Kata Terbuka / Tertutup',
        perkataan: 'buku',
        jenisAktiviti: 'SUSUN_SUKU_KATA',
        markah: 100,
        bilanganBintang: 3,
        dikuasai: true,
        bilanganPercubaan: 1,
        kesilapanKerap: [],
        tempohSaat: 14,
        tarikhMasa: new Date(Date.now() - 1000 * 60 * 35).toISOString(),
      },
      {
        id: 'rekod-p2',
        muridId: 'm2',
        namaMurid: 'Siti Nur Aisyah binti Zulkifli',
        kelas: '2 Bijak',
        kemahiranId: 'K4_PERKATAAN_KVKV',
        namaKemahiran: 'Mengeja & Menyusun Huruf Asas',
        perkataan: 'bola',
        jenisAktiviti: 'SUSUN_HURUF',
        markah: 100,
        bilanganBintang: 3,
        dikuasai: true,
        bilanganPercubaan: 1,
        kesilapanKerap: [],
        tempohSaat: 11,
        tarikhMasa: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
      },
      {
        id: 'rekod-p3',
        muridId: 'm3',
        namaMurid: 'Danial Hakim bin Azman',
        kelas: '3 Cekap',
        kemahiranId: 'K5_PERKATAAN_V_KVK',
        namaKemahiran: 'Susun Suku Kata Terbuka / Tertutup',
        perkataan: 'ayam',
        jenisAktiviti: 'SUSUN_SUKU_KATA',
        markah: 80,
        bilanganBintang: 2,
        dikuasai: true,
        bilanganPercubaan: 2,
        kesilapanKerap: ['yam-a (sepatutnya a-yam)'],
        tempohSaat: 22,
        tarikhMasa: new Date(Date.now() - 1000 * 60 * 8).toISOString(),
      },
    ];
  });

  // Mod Navigasi Aplikasi
  const [modSemasa, setModSemasa] = useState<ModAktiviti>('SUKU_KATA');
  // Indeks Soalan Semasa
  const [indeksSoalan, setIndeksSoalan] = useState<number>(0);

  // Simpan data ke dalam localStorage secara automatik
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_MURID, JSON.stringify(senaraiMurid));
  }, [senaraiMurid]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_REKOD, JSON.stringify(senaraiRekod));
  }, [senaraiRekod]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_MURID_AKTIF, muridAktif.id);
  }, [muridAktif]);

  // Soalan Aktif
  const soalanSemasa = DATA_SOALAN_AKTIVITI[indeksSoalan % DATA_SOALAN_AKTIVITI.length];

  // Fungsi mengendalikan penyelesaian aktiviti murid & perekodan automatik PBD
  const handleSelesaiAktiviti = (rekodBaru: RekodPembelajaran) => {
    // Tambah rekod terkini ke senarai rekod (papan pemuka kemaskini masa nyata)
    setSenaraiRekod((prev) => [...prev, rekodBaru]);

    // Kemaskini bintang dan rekod murid
    setSenaraiMurid((prev) =>
      prev.map((m) => {
        if (m.id === muridAktif.id) {
          const bintangBaru = m.bintangTerkumpul + rekodBaru.bilanganBintang;
          // Kenaikan Tahap Penguasaan (TP) automatik sekiranya menguasai pelbagai latihan
          let tahapBaru = m.tahapSemasa;
          if (bintangBaru >= 45) tahapBaru = 'TP5';
          else if (bintangBaru >= 30) tahapBaru = 'TP4';
          else if (bintangBaru >= 15) tahapBaru = 'TP3';
          else if (bintangBaru >= 6) tahapBaru = 'TP2';

          return {
            ...m,
            bintangTerkumpul: bintangBaru,
            tahapSemasa: tahapBaru,
          };
        }
        return m;
      })
    );

    // Kemaskini murid aktif tempatan
    setMuridAktif((prev) => ({
      ...prev,
      bintangTerkumpul: prev.bintangTerkumpul + rekodBaru.bilanganBintang,
    }));
  };

  const handleSoalanSeterusnya = () => {
    bunyi.playPop();
    setIndeksSoalan((prev) => (prev + 1) % DATA_SOALAN_AKTIVITI.length);
  };

  const handleTukarMurid = (muridPilihan: Murid) => {
    bunyi.playPop();
    setMuridAktif(muridPilihan);
    bunyi.sebut(`Selamat datang ${muridPilihan.nama.split(' ')[0]}! Mari kita belajar membaca dan menulis hari ini.`);
  };

  const handleTambahMurid = (muridBaru: Murid) => {
    setSenaraiMurid((prev) => [...prev, muridBaru]);
    setMuridAktif(muridBaru);
    bunyi.playBetul();
    bunyi.sebut(`Murid baharu ${muridBaru.nama} telah berjaya didaftarkan ke Program Pemulihan Khas.`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-slate-50 to-amber-50/40 text-slate-900 flex flex-col font-sans">
      {/* ===================== PALANG NAVIGASI UTAMA (HEADER) ===================== */}
      <header className="no-print sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-sky-100 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          {/* Logo & Penjenamaan Aplikasi */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-gradient-to-tr from-sky-500 to-emerald-500 flex items-center justify-center text-white shadow-md shadow-sky-500/20">
              <span className="text-xl md:text-2xl font-black">📖</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs px-2 py-0.5 bg-amber-100 text-amber-800 font-extrabold rounded-md uppercase tracking-wider">
                  Pemulihan Khas KPM
                </span>
                <span className="text-[10px] text-slate-400 hidden sm:inline">
                  Bahasa Melayu
                </span>
              </div>
              <h1 className="text-base md:text-xl font-black text-slate-900 tracking-tight leading-tight">
                Celik Minda
              </h1>
            </div>
          </div>

          {/* Profil Murid Aktif Ringkas & Butang Pasang PWA */}
          <div className="flex items-center gap-2 md:gap-3">
            {/* Butang Profil Murid Semasa */}
            <div className="flex items-center gap-2 px-3 py-1.5 bg-sky-50 border border-sky-200 rounded-2xl">
              <span className="text-xl">{muridAktif.avatar}</span>
              <div className="hidden sm:block text-left">
                <p className="text-xs font-bold text-slate-800 leading-none">
                  {muridAktif.nama.split(' ')[0]}
                </p>
                <span className="text-[10px] text-amber-600 font-extrabold flex items-center gap-0.5">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  {muridAktif.bintangTerkumpul} Bintang
                </span>
              </div>
            </div>

            {/* Butang Pasang Aplikasi PWA Mengikut Garis Panduan */}
            <PWAInstallButton />
          </div>
        </div>

        {/* Bar Pilihan Mod Pembelajaran & Analitik Guru */}
        <div className="max-w-6xl mx-auto px-4 py-2 border-t border-slate-100 flex items-center gap-2 overflow-x-auto scrollbar-none">
          <button
            onClick={() => {
              bunyi.playPop();
              setModSemasa('SUKU_KATA');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs md:text-sm font-bold whitespace-nowrap transition-all ${
              modSemasa === 'SUKU_KATA'
                ? 'bg-sky-600 text-white shadow-md shadow-sky-600/20'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>1. Susun Suku Kata</span>
          </button>

          <button
            onClick={() => {
              bunyi.playPop();
              setModSemasa('SUSUN_HURUF');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs md:text-sm font-bold whitespace-nowrap transition-all ${
              modSemasa === 'SUSUN_HURUF'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
            <span>2. Susun Huruf (Eja)</span>
          </button>

          <button
            onClick={() => {
              bunyi.playPop();
              setModSemasa('TULIS_ASAS');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs md:text-sm font-bold whitespace-nowrap transition-all ${
              modSemasa === 'TULIS_ASAS'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <PenTool className="w-4 h-4" />
            <span>3. Menulis Garis 4</span>
          </button>

          <button
            onClick={() => {
              bunyi.playPop();
              setModSemasa('PADANAN');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs md:text-sm font-bold whitespace-nowrap transition-all ${
              modSemasa === 'PADANAN'
                ? 'bg-amber-600 text-white shadow-md shadow-amber-600/20'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <Puzzle className="w-4 h-4" />
            <span>4. Padanan Gambar</span>
          </button>

          <div className="h-6 w-[1px] bg-slate-300 mx-1 flex-shrink-0" />

          <button
            onClick={() => {
              bunyi.playPop();
              setModSemasa('PAPAN_PEMUKA_GURU');
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs md:text-sm font-extrabold whitespace-nowrap transition-all ${
              modSemasa === 'PAPAN_PEMUKA_GURU'
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-sky-50 text-sky-800 hover:bg-sky-100 border border-sky-200'
            }`}
          >
            <LineChart className="w-4 h-4 text-amber-400" />
            <span>Papan Pemuka Guru & Analitik</span>
          </button>
        </div>
      </header>

      {/* ===================== KANDUNGAN UTAMA ===================== */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-6">
        {/* Mod 1: Seret & Lepas Suku Kata */}
        {modSemasa === 'SUKU_KATA' && (
          <AktivitiSusunSukuKata
            soalan={soalanSemasa}
            muridSemasa={muridAktif}
            onSelesai={handleSelesaiAktiviti}
            onSoalanSeterusnya={handleSoalanSeterusnya}
          />
        )}

        {/* Mod 2: Seret & Lepas Huruf Ejaan Asas */}
        {modSemasa === 'SUSUN_HURUF' && (
          <AktivitiSusunHuruf
            soalan={soalanSemasa}
            muridSemasa={muridAktif}
            onSelesai={handleSelesaiAktiviti}
            onSoalanSeterusnya={handleSoalanSeterusnya}
          />
        )}

        {/* Mod 3: Menulis Asas Garis 4 KPM */}
        {modSemasa === 'TULIS_ASAS' && (
          <AktivitiMenulisAsas
            soalan={soalanSemasa}
            muridSemasa={muridAktif}
            onSelesai={handleSelesaiAktiviti}
            onSoalanSeterusnya={handleSoalanSeterusnya}
          />
        )}

        {/* Mod 4: Padanan Gambar & Perkataan */}
        {modSemasa === 'PADANAN' && (
          <AktivitiPadananGambar
            muridSemasa={muridAktif}
            onSelesai={handleSelesaiAktiviti}
            onPusinganBaru={() => bunyi.playPop()}
          />
        )}

        {/* Mod 5: Papan Pemuka Analitik Guru Masa Nyata & Laporan PBD */}
        {modSemasa === 'PAPAN_PEMUKA_GURU' && (
          <DashboardGuru
            senaraiMurid={senaraiMurid}
            muridAktif={muridAktif}
            senaraiRekod={senaraiRekod}
            onTukarMuridAktif={handleTukarMurid}
            onTambahMurid={handleTambahMurid}
            onBukaLatihan={() => setModSemasa('SUKU_KATA')}
          />
        )}
      </main>

      {/* ===================== KAKI HALAMAN (FOOTER) ===================== */}
      <footer className="no-print mt-auto py-5 bg-white border-t border-slate-200 text-center text-xs text-slate-500">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="flex items-center gap-1.5 font-medium">
            <span className="font-extrabold text-sky-700">Celik Minda Pemulihan Khas</span> —
            Kementerian Pendidikan Malaysia (KPM).
          </p>
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>Tulisan: Century Gothic</span>
            <span>•</span>
            <span>Pentaksiran Bilik Darjah (PBD)</span>
            <span>•</span>
            <span>Aplikasi Luar Talian (PWA)</span>
          </div>
        </div>
      </footer>

      {/* Penunjuk status ketersambungan Luar Talian PWA */}
      <OfflineIndicator />
    </div>
  );
}

import React, { useRef, useState, useEffect } from 'react';
import { ItemAktiviti, Murid, RekodPembelajaran } from '../types';
import { bunyi } from '../utils/soundEngine';
import confetti from 'canvas-confetti';
import { Volume2, RotateCcw, Check, Star, Sparkles, HelpCircle, Palette, Eraser, PenLine } from 'lucide-react';

interface Props {
  soalan: ItemAktiviti;
  muridSemasa: Murid;
  onSelesai: (rekod: RekodPembelajaran) => void;
  onSoalanSeterusnya: () => void;
}

export const AktivitiMenulisAsas: React.FC<Props> = ({
  soalan,
  muridSemasa,
  onSelesai,
  onSoalanSeterusnya,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [warnaPen, setWarnaPen] = useState<string>('#0284c7');
  const [saizPen, setSaizPen] = useState<number>(6);
  const [modPemadam, setModPemadam] = useState<boolean>(false);
  const [telahMenulis, setTelahMenulis] = useState<boolean>(false);
  const [statusSelesai, setStatusSelesai] = useState<boolean>(false);
  const masaMulaRef = useRef<number>(Date.now());

  useEffect(() => {
    masaMulaRef.current = Date.now();
    setStatusSelesai(false);
    setTelahMenulis(false);
    bersihkanKanvas();
    bunyi.sebut(`Latihan menulis. Surih dan tulis perkataan ${soalan.perkataan} pada garisan empat buku latihan ini.`);
  }, [soalan]);

  const bersihkanKanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setTelahMenulis(false);
  };

  const getPosisi = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    let clientX = 0;
    let clientY = 0;

    if ('touches' in e && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('clientX' in e) {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  };

  const startDraw = (e: React.MouseEvent | React.TouchEvent) => {
    if (statusSelesai) return;
    e.preventDefault();
    setIsDrawing(true);
    setTelahMenulis(true);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getPosisi(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = modPemadam ? 24 : saizPen;
    ctx.strokeStyle = modPemadam ? '#ffffff' : warnaPen;

    bunyi.playPop();
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || statusSelesai) return;
    e.preventDefault();

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getPosisi(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDraw = () => {
    setIsDrawing(false);
  };

  const semakDanHantarTulisan = () => {
    if (!telahMenulis) {
      bunyi.sebut('Sila surih atau tulis huruf terlebih dahulu sebelum menyemak.');
      return;
    }

    bunyi.playBetul();
    setTimeout(() => bunyi.playKemenangan(), 200);

    confetti({
      particleCount: 75,
      spread: 60,
      origin: { y: 0.6 },
    });

    setStatusSelesai(true);
    bunyi.sebut(`Tahniah ${muridSemasa.nama.split(' ')[0]}! Tulisan anda sangat kemas dan mematuhi panduan garisan.`);

    const tempoh = Math.max(1, Math.round((Date.now() - masaMulaRef.current) / 1000));

    const rekod: RekodPembelajaran = {
      id: `rekod-${Date.now()}`,
      muridId: muridSemasa.id,
      namaMurid: muridSemasa.nama,
      kelas: muridSemasa.kelas,
      kemahiranId: soalan.kategori,
      namaKemahiran: 'Kemahiran Menulis Asas Garis 4 KPM',
      perkataan: soalan.perkataan,
      jenisAktiviti: 'TULIS_ASAS',
      markah: 100,
      bilanganBintang: 3,
      dikuasai: true,
      bilanganPercubaan: 1,
      kesilapanKerap: [],
      tempohSaat: tempoh,
      tarikhMasa: new Date().toISOString(),
    };

    onSelesai(rekod);
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 md:p-6 bg-white rounded-3xl shadow-xl border-4 border-indigo-100 flex flex-col items-center">
      {/* Bar Atas */}
      <div className="w-full flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-indigo-100">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{muridSemasa.avatar}</span>
          <div>
            <h3 className="font-bold text-slate-800 text-sm md:text-base leading-tight">
              {muridSemasa.nama}
            </h3>
            <p className="text-xs text-indigo-600 font-semibold">
              Kemahiran Menulis Asas (Garis Empat KPM)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => bunyi.sebut(soalan.perkataan)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-100 hover:bg-indigo-200 text-indigo-800 rounded-xl text-xs md:text-sm font-bold transition-colors"
          >
            <Volume2 className="w-4 h-4 text-indigo-600" />
            <span>Sebut</span>
          </button>
        </div>
      </div>

      {/* Arahan Menulis */}
      <div className="my-4 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-indigo-50 border border-indigo-200 rounded-full text-indigo-900 text-xs md:text-sm font-bold mb-2">
          <PenLine className="w-4 h-4 text-indigo-500" />
          <span>Aktiviti Menulis & Menyurih KPM</span>
        </div>
        <h2 className="text-lg md:text-2xl font-bold text-slate-900 leading-snug">
          Bolehkah anda menulis perkataan “{soalan.perkataan}” mengikut panduan garisan ini?
        </h2>
        <p className="text-xs md:text-sm text-slate-500 mt-1">
          Gunakan jari atau tetikus untuk menyurih huruf berpandukan garisan merah dan biru standard buku latihan KPM.
        </p>
      </div>

      {/* Gambar Petunjuk Kecil */}
      <div className="flex items-center gap-4 p-3 bg-indigo-50/60 rounded-2xl border border-indigo-100 mb-3">
        <div
          className="w-14 h-14 md:w-16 md:h-16 flex-shrink-0"
          dangerouslySetInnerHTML={{ __html: soalan.simbolSvg }}
        />
        <div>
          <span className="text-xs font-bold text-indigo-700 uppercase">Petunjuk Gambar:</span>
          <p className="text-sm font-extrabold text-slate-800 uppercase tracking-widest">{soalan.perkataan}</p>
          <span className="text-xs text-slate-500">Suku kata: {soalan.sukuKata.join(' - ')}</span>
        </div>
      </div>

      {/* Kanvas Menulis Bergaris Garis 4 KPM */}
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-inner border-2 border-indigo-200 overflow-hidden">
        {/* Latar Garisan 4 Latihan Menulis KPM */}
        <div className="absolute inset-0 pointer-events-none flex flex-col justify-around py-4 px-6 opacity-85 select-none">
          {/* Baris Garisan KPM */}
          <div className="w-full h-28 relative flex items-center justify-center">
            {/* Garis atas (Merah) */}
            <div className="absolute top-2 left-0 right-0 h-[2px] bg-rose-400"></div>
            {/* Garis tengah putus-putus (Kelabu) */}
            <div className="absolute top-1/2 left-0 right-0 h-[2px] border-b-2 border-dashed border-slate-400"></div>
            {/* Garis bawah (Biru) */}
            <div className="absolute bottom-2 left-0 right-0 h-[2px] bg-sky-500"></div>

            {/* Tulisan Model Bintik-bintik (Century Gothic Dotted Guide) */}
            <div className="text-5xl md:text-6xl font-black text-slate-300 tracking-[0.3em] uppercase select-none opacity-40">
              {soalan.perkataan}
            </div>
          </div>
        </div>

        {/* Kanvas Sentuh Sebenar */}
        <canvas
          ref={canvasRef}
          width={700}
          height={180}
          onMouseDown={startDraw}
          onMouseMove={draw}
          onMouseUp={stopDraw}
          onMouseLeave={stopDraw}
          onTouchStart={startDraw}
          onTouchMove={draw}
          onTouchEnd={stopDraw}
          className="relative z-10 w-full h-[180px] touch-none cursor-crosshair bg-transparent"
        />
      </div>

      {/* Bar Alatan Pen & Warna */}
      <div className="w-full max-w-2xl mt-4 flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-200">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500">Warna Pen:</span>
          {[
            { nama: 'Biru', kod: '#0284c7' },
            { nama: 'Merah', kod: '#dc2626' },
            { nama: 'Hijau', kod: '#16a34a' },
            { nama: 'Ungu', kod: '#7c3aed' },
          ].map((w) => (
            <button
              key={w.kod}
              onClick={() => {
                setWarnaPen(w.kod);
                setModPemadam(false);
              }}
              style={{ backgroundColor: w.kod }}
              className={`w-7 h-7 rounded-full transition-transform ${
                warnaPen === w.kod && !modPemadam ? 'scale-125 ring-2 ring-offset-2 ring-slate-400' : 'hover:scale-110'
              }`}
              title={`Pen ${w.nama}`}
            />
          ))}

          <button
            onClick={() => setModPemadam(true)}
            className={`p-1.5 rounded-xl border transition-colors ${
              modPemadam ? 'bg-amber-100 text-amber-800 border-amber-300' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
            title="Gunakan Pemadam"
          >
            <Eraser className="w-4 h-4" />
          </button>

          <button
            onClick={bersihkanKanvas}
            className="p-1.5 rounded-xl bg-white text-slate-500 border border-slate-200 hover:bg-slate-100 transition-colors"
            title="Bersihkan Semua Tulisan"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-2">
          {!statusSelesai ? (
            <button
              onClick={semakDanHantarTulisan}
              disabled={!telahMenulis}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-700 hover:to-sky-700 disabled:opacity-40 text-white text-xs md:text-sm font-bold rounded-xl shadow-md transition-all active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Semak Tulisan</span>
            </button>
          ) : (
            <button
              onClick={onSoalanSeterusnya}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs md:text-sm font-bold rounded-xl shadow-md transition-all active:scale-95"
            >
              <span>Tulisan Seterusnya</span>
              <Sparkles className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Kad Pujian Guru */}
      {statusSelesai && (
        <div className="w-full max-w-2xl mt-4 p-4 bg-emerald-50 rounded-2xl border-2 border-emerald-300 text-center animate-in zoom-in-95">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Star className="w-7 h-7 text-amber-400 fill-amber-400 animate-bounce" />
            <Star className="w-7 h-7 text-amber-400 fill-amber-400 animate-bounce delay-75" />
            <Star className="w-7 h-7 text-amber-400 fill-amber-400 animate-bounce delay-150" />
          </div>
          <h4 className="font-black text-emerald-800 text-lg">Syabas! Latihan Menulis Selesai</h4>
          <p className="text-xs md:text-sm text-slate-600 mt-1">
            Kemahiran motor halus dan koordinasi mata-tangan murid telah direkodkan dalam PBD Pemulihan Khas.
          </p>
        </div>
      )}
    </div>
  );
};

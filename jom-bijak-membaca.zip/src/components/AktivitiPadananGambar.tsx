import React, { useState, useEffect, useRef } from 'react';
import { ItemAktiviti, Murid, RekodPembelajaran } from '../types';
import { DATA_SOALAN_AKTIVITI } from '../data/kemahiranData';
import { bunyi } from '../utils/soundEngine';
import confetti from 'canvas-confetti';
import { Volume2, RotateCcw, ArrowRight, Star, Sparkles, HelpCircle, CheckCircle2 } from 'lucide-react';

interface Props {
  muridSemasa: Murid;
  onSelesai: (rekod: RekodPembelajaran) => void;
  onPusinganBaru: () => void;
}

export const AktivitiPadananGambar: React.FC<Props> = ({
  muridSemasa,
  onSelesai,
  onPusinganBaru,
}) => {
  const [senaraiGambar, setSenaraiGambar] = useState<ItemAktiviti[]>([]);
  const [senaraiPerkataan, setSenaraiPerkataan] = useState<{ id: string; perkataan: string }[]>([]);
  const [padanan, setPadanan] = useState<{ [gambarId: string]: string }>({});
  const [statusSelesai, setStatusSelesai] = useState<boolean>(false);
  const [percubaan, setPercubaan] = useState<number>(0);
  const masaMulaRef = useRef<number>(Date.now());

  useEffect(() => {
    mulakanPusingan();
  }, []);

  const mulakanPusingan = () => {
    masaMulaRef.current = Date.now();
    setStatusSelesai(false);
    setPadanan({});
    setPercubaan(0);

    // Ambil 4 soalan secara rawak
    const rawak = [...DATA_SOALAN_AKTIVITI]
      .sort(() => Math.random() - 0.5)
      .slice(0, 4);

    setSenaraiGambar(rawak);

    // Rawakkan susunan kad perkataan
    const perkataanAcak = rawak
      .map((item) => ({ id: item.id, perkataan: item.perkataan }))
      .sort(() => Math.random() - 0.5);

    setSenaraiPerkataan(perkataanAcak);

    bunyi.sebut('Aktiviti padankan gambar. Tarik kad perkataan dan padankan dengan gambar yang betul.');
  };

  const handleDragStart = (e: React.DragEvent, id: string, perkataan: string) => {
    e.dataTransfer.setData('text/plain', JSON.stringify({ id, perkataan }));
    bunyi.playPop();
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetGambarId: string) => {
    e.preventDefault();
    if (statusSelesai) return;

    try {
      const dataStr = e.dataTransfer.getData('text/plain');
      if (!dataStr) return;
      const { id, perkataan } = JSON.parse(dataStr);
      padankanItem(targetGambarId, id, perkataan);
    } catch {
      // Abaikan ralat seretan
    }
  };

  const padankanItem = (gambarId: string, perkataanId: string, perkataan: string) => {
    const kiraPercubaan = percubaan + 1;
    setPercubaan(kiraPercubaan);

    if (gambarId === perkataanId) {
      // Tepat!
      bunyi.playBetul();
      bunyi.sebut(`Betul! ${perkataan}.`);

      const padananBaru = { ...padanan, [gambarId]: perkataan };
      setPadanan(padananBaru);

      // Keluarkan dari senarai perkataan belum dipadan
      setSenaraiPerkataan((prev) => prev.filter((p) => p.id !== perkataanId));

      // Semak sekiranya kesemua 4 gambar telah berjaya dipadankan
      if (Object.keys(padananBaru).length === senaraiGambar.length) {
        setTimeout(() => bunyi.playKemenangan(), 300);
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });

        setStatusSelesai(true);
        const tempoh = Math.max(1, Math.round((Date.now() - masaMulaRef.current) / 1000));

        const rekod: RekodPembelajaran = {
          id: `rekod-${Date.now()}`,
          muridId: muridSemasa.id,
          namaMurid: muridSemasa.nama,
          kelas: muridSemasa.kelas,
          kemahiranId: 'K4_PERKATAAN_KVKV',
          namaKemahiran: 'Padanan Gambar & Perkataan',
          perkataan: '4 Perkataan Bergambar',
          jenisAktiviti: 'PADAN_GAMBAR',
          markah: 100,
          bilanganBintang: 3,
          dikuasai: true,
          bilanganPercubaan: kiraPercubaan,
          kesilapanKerap: [],
          tempohSaat: tempoh,
          tarikhMasa: new Date().toISOString(),
        };

        onSelesai(rekod);
      }
    } else {
      // Tidak sepadan
      bunyi.playCubaLagi();
      bunyi.sebut('Gambar dan perkataan tidak sepadan. Cuba padankan sekali lagi.');
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 md:p-6 bg-white rounded-3xl shadow-xl border-4 border-amber-100 flex flex-col items-center">
      {/* Bar Atas */}
      <div className="w-full flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-amber-100">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{muridSemasa.avatar}</span>
          <div>
            <h3 className="font-bold text-slate-800 text-sm md:text-base leading-tight">
              {muridSemasa.nama}
            </h3>
            <p className="text-xs text-amber-600 font-semibold">
              Padanan Gambar & Perkataan
            </p>
          </div>
        </div>

        <button
          onClick={mulakanPusingan}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-xl text-xs md:text-sm font-bold transition-colors"
        >
          <RotateCcw className="w-4 h-4 text-amber-700" />
          <span>Set Semula</span>
        </button>
      </div>

      {/* Soalan */}
      <div className="my-4 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-amber-50 border border-amber-200 rounded-full text-amber-900 text-xs md:text-sm font-bold mb-2">
          <HelpCircle className="w-4 h-4 text-amber-500" />
          <span>Aktiviti Padanan Pintar</span>
        </div>
        <h2 className="text-lg md:text-2xl font-bold text-slate-900 leading-snug">
          Bolehkah anda memadankan setiap gambar dengan perkataan yang betul?
        </h2>
        <p className="text-xs md:text-sm text-slate-500 mt-1">
          Tarik kad perkataan berwarna ungu di bawah dan lepaskan tepat di atas gambar yang sepadan.
        </p>
      </div>

      {/* Grid 4 Gambar Sasaran */}
      <div className="w-full grid grid-cols-2 md:grid-cols-4 gap-4 my-4">
        {senaraiGambar.map((item) => {
          const perkataanDipadan = padanan[item.id];
          return (
            <div
              key={item.id}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, item.id)}
              className={`p-3 rounded-2xl border-3 flex flex-col items-center justify-between transition-all ${
                perkataanDipadan
                  ? 'bg-emerald-50 border-emerald-400 shadow-md scale-102'
                  : 'bg-slate-50 border-dashed border-amber-300 hover:border-amber-500 slot-active'
              }`}
            >
              <div
                className="w-24 h-24 md:w-28 md:h-28 flex items-center justify-center p-1"
                dangerouslySetInnerHTML={{ __html: item.simbolSvg }}
              />

              <div className="w-full mt-3">
                {perkataanDipadan ? (
                  <div className="w-full py-2 bg-emerald-600 text-white font-black text-center rounded-xl text-sm md:text-base flex items-center justify-center gap-1.5 shadow">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{perkataanDipadan}</span>
                  </div>
                ) : (
                  <div className="w-full py-2 bg-amber-100/70 border border-amber-300 text-amber-800 text-xs font-bold text-center rounded-xl">
                    Lepaskan di sini
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Pilihan Kad Perkataan */}
      <div className="w-full my-4 p-4 bg-slate-50 rounded-2xl border border-slate-200">
        <div className="text-center text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
          Kad Perkataan Untuk Ditarik:
        </div>
        <div className="flex flex-wrap items-center justify-center gap-3 min-h-[50px]">
          {senaraiPerkataan.length === 0 && !statusSelesai && (
            <span className="text-xs text-slate-400 italic">
              Semua perkataan telah berjaya dipadankan!
            </span>
          )}

          {senaraiPerkataan.map((item) => (
            <div
              key={item.id}
              draggable={!statusSelesai}
              onDragStart={(e) => handleDragStart(e, item.id, item.perkataan)}
              className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-black text-lg rounded-2xl shadow-md cursor-grab active:cursor-grabbing active:scale-95 transition-all select-none border border-purple-400"
            >
              {item.perkataan}
            </div>
          ))}
        </div>
      </div>

      {/* Status Tamat */}
      {statusSelesai && (
        <div className="w-full mt-4 p-5 bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 rounded-2xl border-2 border-emerald-300 shadow-lg flex flex-col items-center text-center animate-in zoom-in-95">
          <div className="flex items-center gap-1.5 mb-2">
            {[1, 2, 3].map((star) => (
              <Star key={star} className="w-8 h-8 text-amber-400 fill-amber-400 animate-bounce" />
            ))}
          </div>

          <h3 className="text-xl md:text-2xl font-black text-emerald-800 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-amber-500" />
            Hebat! Semua Padanan Gambar Tepat!
          </h3>

          <p className="text-xs md:text-sm text-slate-600 mt-1">
            Data penilaian kemahiran padanan telah direkodkan dalam laporan PBD murid secara automatik.
          </p>

          <button
            onClick={() => {
              mulakanPusingan();
              onPusinganBaru();
            }}
            className="mt-4 inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-base rounded-2xl shadow-md active:scale-95 transition-all"
          >
            <span>Pusingan Padanan Baharu</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
};

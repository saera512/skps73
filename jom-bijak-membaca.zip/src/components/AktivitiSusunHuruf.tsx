import React, { useState, useEffect, useRef } from 'react';
import { ItemAktiviti, Murid, RekodPembelajaran } from '../types';
import { bunyi } from '../utils/soundEngine';
import confetti from 'canvas-confetti';
import { Volume2, RotateCcw, ArrowRight, Star, Sparkles, HelpCircle, Check, AlertTriangle } from 'lucide-react';

interface Props {
  soalan: ItemAktiviti;
  muridSemasa: Murid;
  onSelesai: (rekod: RekodPembelajaran) => void;
  onSoalanSeterusnya: () => void;
}

const HURUF_VOKAL = ['a', 'e', 'i', 'o', 'u'];

export const AktivitiSusunHuruf: React.FC<Props> = ({
  soalan,
  muridSemasa,
  onSelesai,
  onSoalanSeterusnya,
}) => {
  const [pilihanHuruf, setPilihanHuruf] = useState<{ id: string; char: string }[]>([]);
  const [petakHuruf, setPetakHuruf] = useState<(string | null)[]>([]);
  const [percubaan, setPercubaan] = useState<number>(0);
  const [kesilapanKerap, setKesilapanKerap] = useState<string[]>([]);
  const [statusSelesai, setStatusSelesai] = useState<boolean>(false);
  const [bintangDapat, setBintangDapat] = useState<number>(3);
  const [sedangGoncang, setSedangGoncang] = useState<boolean>(false);
  const masaMulaRef = useRef<number>(Date.now());

  useEffect(() => {
    masaMulaRef.current = Date.now();
    setPetakHuruf(new Array(soalan.huruf.length).fill(null));
    setPercubaan(0);
    setKesilapanKerap([]);
    setStatusSelesai(false);
    setBintangDapat(3);

    // Rawakkan huruf
    const scrambled = soalan.huruf
      .map((char, index) => ({ id: `${char}-${index}-${Math.random()}`, char }))
      .sort(() => Math.random() - 0.5);

    setPilihanHuruf(scrambled);

    bunyi.sebut(`Eja perkataan ${soalan.perkataan}. Susun huruf satu demi satu.`);
  }, [soalan]);

  const handleDragStart = (e: React.DragEvent, char: string, id: string) => {
    e.dataTransfer.setData('text/plain', JSON.stringify({ char, id }));
    bunyi.playPop();
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (statusSelesai) return;

    try {
      const dataStr = e.dataTransfer.getData('text/plain');
      if (!dataStr) return;
      const { char, id } = JSON.parse(dataStr);
      isiHurufKePetak(char, id, index);
    } catch {
      // Abaikan ralat seretan
    }
  };

  const handleKlikPilihan = (item: { id: string; char: string }) => {
    if (statusSelesai) return;
    const indeksKosong = petakHuruf.findIndex((p) => p === null);
    if (indeksKosong !== -1) {
      isiHurufKePetak(item.char, item.id, indeksKosong);
    }
  };

  const handlePadamHuruf = (index: number) => {
    if (statusSelesai) return;
    const char = petakHuruf[index];
    if (!char) return;

    bunyi.playPop();
    const petakBaru = [...petakHuruf];
    petakBaru[index] = null;
    setPetakHuruf(petakBaru);

    setPilihanHuruf((prev) => [...prev, { id: `${char}-${Date.now()}`, char }]);
  };

  const isiHurufKePetak = (char: string, id: string, targetIndex: number) => {
    const hurufSediaAda = petakHuruf[targetIndex];
    let pilihanBaru = pilihanHuruf.filter((p) => p.id !== id);

    if (hurufSediaAda) {
      pilihanBaru = [...pilihanBaru, { id: `${hurufSediaAda}-${Date.now()}`, char: hurufSediaAda }];
    }

    const petakBaru = [...petakHuruf];
    petakBaru[targetIndex] = char;

    setPilihanHuruf(pilihanBaru);
    setPetakHuruf(petakBaru);
    bunyi.playPop();

    // Bunyikan fonik huruf yang diletakkan
    bunyi.sebut(char, 1.0);

    // Semak sekiranya kesemua petak sudah lengkap
    if (petakBaru.every((p) => p !== null)) {
      const ejaanMurid = petakBaru.join('');
      const ejaanBetul = soalan.huruf.join('');
      const kiraPercubaan = percubaan + 1;
      setPercubaan(kiraPercubaan);

      if (ejaanMurid.toLowerCase() === ejaanBetul.toLowerCase()) {
        // Berjaya!
        bunyi.playBetul();
        setTimeout(() => bunyi.playKemenangan(), 300);

        confetti({
          particleCount: 90,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#0ea5e9', '#f59e0b', '#10b981', '#f43f5e'],
        });

        const tempoh = Math.max(1, Math.round((Date.now() - masaMulaRef.current) / 1000));
        let markahBintang = 3;
        if (kiraPercubaan > 2) markahBintang = 1;
        else if (kiraPercubaan > 1) markahBintang = 2;

        setBintangDapat(markahBintang);
        setStatusSelesai(true);

        bunyi.sebut(`Bagus sekali ${muridSemasa.nama.split(' ')[0]}! Ejaan bagi ${soalan.perkataan} adalah tepat!`);

        const rekod: RekodPembelajaran = {
          id: `rekod-${Date.now()}`,
          muridId: muridSemasa.id,
          namaMurid: muridSemasa.nama,
          kelas: muridSemasa.kelas,
          kemahiranId: soalan.kategori,
          namaKemahiran: 'Mengeja & Menyusun Huruf Asas',
          perkataan: soalan.perkataan,
          jenisAktiviti: 'SUSUN_HURUF',
          markah: markahBintang === 3 ? 100 : markahBintang === 2 ? 80 : 60,
          bilanganBintang: markahBintang,
          dikuasai: true,
          bilanganPercubaan: kiraPercubaan,
          kesilapanKerap,
          tempohSaat: tempoh,
          tarikhMasa: new Date().toISOString(),
        };

        onSelesai(rekod);
      } else {
        // Kesilapan Ejaan
        bunyi.playCubaLagi();
        setSedangGoncang(true);
        setTimeout(() => setSedangGoncang(false), 500);

        // Pengesanan Diagnostik Kesilapan Huruf Pemulihan KPM
        let diagnosis = `${ejaanMurid} (Betul: ${ejaanBetul})`;
        if (
          (ejaanMurid.includes('d') && ejaanBetul.includes('b')) ||
          (ejaanMurid.includes('b') && ejaanBetul.includes('d'))
        ) {
          diagnosis += ' [Kekeliruan b vs d]';
        }
        if (
          (ejaanMurid.includes('p') && ejaanBetul.includes('q')) ||
          (ejaanMurid.includes('q') && ejaanBetul.includes('p'))
        ) {
          diagnosis += ' [Kekeliruan p vs q]';
        }

        setKesilapanKerap((prev) => [...prev, diagnosis]);
        bunyi.sebut('Belum tepat, mari kita cuba sekali lagi!');
      }
    }
  };

  const sebutPerkataanPenuh = () => {
    bunyi.sebut(soalan.perkataan);
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 md:p-6 bg-white rounded-3xl shadow-xl border-4 border-emerald-100 flex flex-col items-center">
      {/* Bar Atas */}
      <div className="w-full flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-emerald-100">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{muridSemasa.avatar}</span>
          <div>
            <h3 className="font-bold text-slate-800 text-sm md:text-base leading-tight">
              {muridSemasa.nama}
            </h3>
            <p className="text-xs text-emerald-600 font-semibold">
              Ejaan Huruf Asas • Tahap: {muridSemasa.tahapSemasa}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Petunjuk Warna Pedagogi Pemulihan KPM */}
          <div className="hidden sm:flex items-center gap-2 text-xs font-semibold px-2.5 py-1 bg-slate-100 rounded-lg">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" /> Vokal
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-500 inline-block" /> Konsonan
            </span>
          </div>

          <button
            onClick={sebutPerkataanPenuh}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl text-xs md:text-sm font-bold transition-colors"
          >
            <Volume2 className="w-4 h-4 text-emerald-600" />
            <span>Sebut</span>
          </button>
        </div>
      </div>

      {/* Soalan */}
      <div className="my-4 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-emerald-50 border border-emerald-200 rounded-full text-emerald-900 text-xs md:text-sm font-bold mb-2">
          <HelpCircle className="w-4 h-4 text-emerald-500" />
          <span>Aktiviti Seret & Lepas Huruf</span>
        </div>
        <h2 className="text-lg md:text-2xl font-bold text-slate-900 leading-snug">
          Bolehkah anda mengeja perkataan ini dengan menyusun huruf yang betul?
        </h2>
        <p className="text-xs md:text-sm text-slate-500 mt-1">
          Tarik kad huruf di bawah dan letakkan mengikut susunan ejaan yang tepat.
        </p>
      </div>

      {/* Ilustrasi Gambar */}
      <div className="relative my-3 w-40 h-40 md:w-52 md:h-52 p-3 bg-gradient-to-b from-emerald-50 to-white rounded-3xl border-2 border-emerald-200 shadow-inner flex items-center justify-center">
        <div
          className="w-full h-full flex items-center justify-center"
          dangerouslySetInnerHTML={{ __html: soalan.simbolSvg }}
        />
        <button
          onClick={sebutPerkataanPenuh}
          className="absolute bottom-2 right-2 p-2 bg-white/90 hover:bg-white text-emerald-600 rounded-full shadow-md border border-emerald-100 active:scale-90 transition-transform"
        >
          <Volume2 className="w-4 h-4" />
        </button>
      </div>

      {/* Kotak Ejaan Huruf (Drop Zone) */}
      <div className="my-4">
        <div className="text-center text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
          Susunan Huruf Ejaan ({soalan.huruf.length} Huruf)
        </div>
        <div
          className={`flex items-center justify-center gap-2 md:gap-3 flex-wrap ${
            sedangGoncang ? 'animate-wiggle' : ''
          }`}
        >
          {petakHuruf.map((char, index) => {
            const isVokal = char ? HURUF_VOKAL.includes(char.toLowerCase()) : false;
            return (
              <div
                key={index}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, index)}
                onClick={() => handlePadamHuruf(index)}
                className={`w-14 h-16 md:w-20 md:h-22 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all border-3 ${
                  char
                    ? isVokal
                      ? 'bg-rose-500 text-white border-rose-600 shadow-md scale-105'
                      : 'bg-sky-600 text-white border-sky-700 shadow-md scale-105'
                    : 'bg-slate-50 border-dashed border-emerald-300 hover:border-emerald-500 slot-active'
                }`}
              >
                {char ? (
                  <span className="text-3xl md:text-4xl font-black drop-shadow-sm">
                    {char}
                  </span>
                ) : (
                  <span className="text-xs text-emerald-400 font-bold">
                    {index + 1}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Pilihan Kad Huruf */}
      <div className="w-full my-4 p-4 bg-slate-50 rounded-2xl border border-slate-200">
        <div className="text-center text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
          Pilihan Huruf (Tarik atau Sentuh):
        </div>
        <div className="flex flex-wrap items-center justify-center gap-2.5 md:gap-4 min-h-[64px]">
          {pilihanHuruf.map((item) => {
            const isVokal = HURUF_VOKAL.includes(item.char.toLowerCase());
            return (
              <div
                key={item.id}
                draggable={!statusSelesai}
                onDragStart={(e) => handleDragStart(e, item.char, item.id)}
                onClick={() => handleKlikPilihan(item)}
                className={`w-14 h-16 md:w-20 md:h-20 rounded-2xl flex items-center justify-center text-2xl md:text-3xl font-black cursor-grab active:cursor-grabbing active:scale-95 shadow-md hover:shadow-lg transition-all border-2 select-none ${
                  isVokal
                    ? 'bg-rose-100 hover:bg-rose-200 text-rose-800 border-rose-300'
                    : 'bg-sky-100 hover:bg-sky-200 text-sky-800 border-sky-300'
                }`}
              >
                {item.char}
              </div>
            );
          })}
        </div>
      </div>

      {/* Ganjaran Selesai */}
      {statusSelesai && (
        <div className="w-full mt-4 p-5 bg-gradient-to-r from-emerald-50 via-teal-50 to-green-50 rounded-2xl border-2 border-emerald-300 shadow-lg flex flex-col items-center text-center animate-in zoom-in-95">
          <div className="flex items-center gap-1.5 mb-2">
            {[1, 2, 3].map((star) => (
              <Star
                key={star}
                className={`w-8 h-8 ${
                  star <= bintangDapat
                    ? 'text-amber-400 fill-amber-400 animate-bounce'
                    : 'text-slate-300'
                }`}
              />
            ))}
          </div>

          <h3 className="text-xl md:text-2xl font-black text-emerald-800 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-amber-500" />
            Cemerlang! Ejaan Tepat Sekali!
          </h3>

          <p className="text-base text-slate-700 mt-1">
            Perkataan: <span className="font-black text-emerald-700 uppercase tracking-widest">{soalan.perkataan}</span>
          </p>

          <button
            onClick={onSoalanSeterusnya}
            className="mt-4 inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-base rounded-2xl shadow-md active:scale-95 transition-all"
          >
            <span>Soalan Seterusnya</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
};

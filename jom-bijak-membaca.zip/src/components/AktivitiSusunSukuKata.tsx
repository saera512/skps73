import React, { useState, useEffect, useRef } from 'react';
import { ItemAktiviti, Murid, RekodPembelajaran } from '../types';
import { bunyi } from '../utils/soundEngine';
import confetti from 'canvas-confetti';
import { Volume2, RotateCcw, ArrowRight, Star, Sparkles, HelpCircle, Award } from 'lucide-react';

interface Props {
  soalan: ItemAktiviti;
  muridSemasa: Murid;
  onSelesai: (rekod: RekodPembelajaran) => void;
  onSoalanSeterusnya: () => void;
}

export const AktivitiSusunSukuKata: React.FC<Props> = ({
  soalan,
  muridSemasa,
  onSelesai,
  onSoalanSeterusnya,
}) => {
  // Susunan suku kata yang telah diacak
  const [pilihanSukuKata, setPilihanSukuKata] = useState<{ id: string; teks: string }[]>([]);
  // Kotak jawapan sasaran
  const [petakJawapan, setPetakJawapan] = useState<(string | null)[]>([]);
  const [percubaan, setPercubaan] = useState<number>(0);
  const [kesilapanList, setKesilapanList] = useState<string[]>([]);
  const [statusSelesai, setStatusSelesai] = useState<boolean>(false);
  const [bintangDapat, setBintangDapat] = useState<number>(3);
  const [sedangGoncang, setSedangGoncang] = useState<boolean>(false);
  const masaMulaRef = useRef<number>(Date.now());

  // Inisialisasi soalan apabila soalan bertukar
  useEffect(() => {
    masaMulaRef.current = Date.now();
    setPetakJawapan(new Array(soalan.sukuKata.length).fill(null));
    setPercubaan(0);
    setKesilapanList([]);
    setStatusSelesai(false);
    setBintangDapat(3);

    // Rawakkan suku kata
    const shuffled = soalan.sukuKata
      .map((teks, idx) => ({ id: `${teks}-${idx}-${Math.random()}`, teks }))
      .sort(() => Math.random() - 0.5);

    setPilihanSukuKata(shuffled);

    // Sebut arahan mesra secara automatik
    bunyi.sebut(`${soalan.petunjukSoalan} Susun suku kata untuk perkataan ini.`);
  }, [soalan]);

  // Kendali seret (Drag & Drop)
  const handleDragStart = (e: React.DragEvent, teks: string, id: string) => {
    e.dataTransfer.setData('text/plain', JSON.stringify({ teks, id }));
    bunyi.playPop();
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (statusSelesai) return;

    try {
      const dataStr = e.dataTransfer.getData('text/plain');
      if (!dataStr) return;
      const { teks, id } = JSON.parse(dataStr);
      letakSukuKataKePetak(teks, id, targetIndex);
    } catch {
      // Abaikan ralat seretan
    }
  };

  // Membolehkan klik / sentuhan pada peranti skrin sentuh (iPad / Telefon)
  const handleKlikPilihan = (item: { id: string; teks: string }) => {
    if (statusSelesai) return;

    // Cari petak kosong pertama
    const indeksKosong = petakJawapan.findIndex((p) => p === null);
    if (indeksKosong !== -1) {
      letakSukuKataKePetak(item.teks, item.id, indeksKosong);
    }
  };

  // Alih keluar suku kata dari petak jawapan jika murid ingin membetulkan
  const handleAlihKeluar = (indeks: number) => {
    if (statusSelesai) return;
    const teksDibuang = petakJawapan[indeks];
    if (!teksDibuang) return;

    bunyi.playPop();
    const petakBaru = [...petakJawapan];
    petakBaru[indeks] = null;
    setPetakJawapan(petakBaru);

    // Kembalikan ke pilihan
    setPilihanSukuKata((prev) => [
      ...prev,
      { id: `${teksDibuang}-${Date.now()}`, teks: teksDibuang },
    ]);
  };

  // Logik meletakkan suku kata dan semak jawapan
  const letakSukuKataKePetak = (teks: string, id: string, targetIndex: number) => {
    // Sekiranya petak sudah ada isi, kembalikan isi lama ke pilihan
    const isiLama = petakJawapan[targetIndex];
    let pilihanBaru = pilihanSukuKata.filter((p) => p.id !== id);

    if (isiLama) {
      pilihanBaru = [...pilihanBaru, { id: `${isiLama}-${Date.now()}`, teks: isiLama }];
    }

    const petakBaru = [...petakJawapan];
    petakBaru[targetIndex] = teks;

    setPilihanSukuKata(pilihanBaru);
    setPetakJawapan(petakBaru);
    bunyi.playPop();

    // Semak sekiranya semua petak telah diisi
    if (petakBaru.every((p) => p !== null)) {
      const jawapanMurid = petakBaru.join('');
      const jawapanBetul = soalan.sukuKata.join('');
      const percubaanTerkini = percubaan + 1;
      setPercubaan(percubaanTerkini);

      if (jawapanMurid.toLowerCase() === jawapanBetul.toLowerCase()) {
        // Jawapan Betul!
        bunyi.playBetul();
        setTimeout(() => bunyi.playKemenangan(), 300);

        // Letuskan konfeti ceria
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#0284c7', '#f59e0b', '#10b981', '#ec4899'],
        });

        const tempohSaat = Math.max(1, Math.round((Date.now() - masaMulaRef.current) / 1000));
        let bintang = 3;
        if (percubaanTerkini > 2) bintang = 1;
        else if (percubaanTerkini > 1) bintang = 2;
        setBintangDapat(bintang);
        setStatusSelesai(true);

        // Sebut pujian BM tulen
        bunyi.sebut(`Syabas ${muridSemasa.nama.split(' ')[0]}! Anda berjaya menyusun suku kata ${soalan.perkataan}!`);

        // Hantar rekod perkembangan automatik
        const rekod: RekodPembelajaran = {
          id: `rekod-${Date.now()}`,
          muridId: muridSemasa.id,
          namaMurid: muridSemasa.nama,
          kelas: muridSemasa.kelas,
          kemahiranId: soalan.kategori,
          namaKemahiran: 'Susun Suku Kata Terbuka / Tertutup',
          perkataan: soalan.perkataan,
          jenisAktiviti: 'SUSUN_SUKU_KATA',
          markah: bintang === 3 ? 100 : bintang === 2 ? 80 : 60,
          bilanganBintang: bintang,
          dikuasai: true,
          bilanganPercubaan: percubaanTerkini,
          kesilapanKerap: kesilapanList,
          tempohSaat,
          tarikhMasa: new Date().toISOString(),
        };
        onSelesai(rekod);
      } else {
        // Jawapan Belum Tepat
        bunyi.playCubaLagi();
        setSedangGoncang(true);
        setTimeout(() => setSedangGoncang(false), 500);

        const silap = `${jawapanMurid} (sepatutnya ${jawapanBetul})`;
        setKesilapanList((prev) => [...prev, silap]);

        bunyi.sebut(`Cuba lagi, susun semula suku kata bagi gambar ${soalan.perkataan}.`);
      }
    }
  };

  const mainkanSuaraPerkataan = () => {
    bunyi.ejaPerkataanFonik(soalan.sukuKata, soalan.perkataan);
  };

  const setSemulaAktiviti = () => {
    setPetakJawapan(new Array(soalan.sukuKata.length).fill(null));
    const shuffled = soalan.sukuKata
      .map((teks, idx) => ({ id: `${teks}-${idx}-${Math.random()}`, teks }))
      .sort(() => Math.random() - 0.5);
    setPilihanSukuKata(shuffled);
    bunyi.playPop();
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 md:p-6 bg-white rounded-3xl shadow-xl border-4 border-sky-100 flex flex-col items-center">
      {/* Bar Atas: Murid & Tajuk Aktiviti */}
      <div className="w-full flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-sky-100">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{muridSemasa.avatar}</span>
          <div>
            <h3 className="font-bold text-slate-800 text-sm md:text-base leading-tight">
              {muridSemasa.nama}
            </h3>
            <p className="text-xs text-sky-600 font-semibold">
              Kelas: {muridSemasa.kelas} • Tahap: {muridSemasa.tahapSemasa}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={mainkanSuaraPerkataan}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-100 hover:bg-sky-200 text-sky-800 rounded-xl text-xs md:text-sm font-bold transition-colors"
            title="Dengar sebutan perkataan"
          >
            <Volume2 className="w-4 h-4 text-sky-600 animate-pulse" />
            <span>Dengar Sebutan</span>
          </button>
          <button
            onClick={setSemulaAktiviti}
            disabled={statusSelesai}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-colors disabled:opacity-40"
            title="Susun semula dari awal"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Soalan Berdasarkan Gambar KPM (Mengikut format tanda soal “?” pengguna) */}
      <div className="my-4 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-amber-50 border border-amber-200 rounded-full text-amber-900 text-xs md:text-sm font-bold mb-2">
          <HelpCircle className="w-4 h-4 text-amber-500" />
          <span>Aktiviti Seret & Lepas Suku Kata</span>
        </div>
        <h2 className="text-lg md:text-2xl font-bold text-slate-900 leading-snug">
          {soalan.petunjukSoalan}
        </h2>
        <p className="text-xs md:text-sm text-slate-500 mt-1">
          Tarik blok suku kata di bawah dan lepaskan ke dalam kotak jawapan mengikut urutan yang betul.
        </p>
      </div>

      {/* Ilustrasi Gambar Vektor Tajam Khas Pemulihan */}
      <div className="relative my-3 w-44 h-44 md:w-56 md:h-56 p-3 bg-gradient-to-b from-sky-50 to-white rounded-3xl border-2 border-sky-200 shadow-inner flex items-center justify-center">
        <div
          className="w-full h-full flex items-center justify-center"
          dangerouslySetInnerHTML={{ __html: soalan.simbolSvg }}
        />
        <button
          onClick={mainkanSuaraPerkataan}
          className="absolute bottom-2 right-2 p-2 bg-white/90 hover:bg-white text-sky-600 rounded-full shadow-md border border-sky-100 active:scale-90 transition-transform"
          title="Bunyikan gambar"
        >
          <Volume2 className="w-4 h-4" />
        </button>
      </div>

      {/* Petak Jawapan Sasaran (Drop Zones) */}
      <div className="my-4">
        <div className="text-center text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
          Kotak Jawapan Murid
        </div>
        <div
          className={`flex items-center justify-center gap-3 md:gap-4 ${
            sedangGoncang ? 'animate-wiggle' : ''
          }`}
        >
          {petakJawapan.map((nilai, index) => (
            <div
              key={index}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, index)}
              onClick={() => handleAlihKeluar(index)}
              className={`w-20 h-20 md:w-28 md:h-24 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all border-3 ${
                nilai
                  ? 'bg-gradient-to-b from-sky-500 to-sky-600 text-white border-sky-600 shadow-lg scale-105'
                  : 'bg-slate-50 border-dashed border-sky-300 hover:border-sky-500 hover:bg-sky-50/50 slot-active'
              }`}
            >
              {nilai ? (
                <span className="text-3xl md:text-4xl font-extrabold tracking-wide drop-shadow-sm">
                  {nilai}
                </span>
              ) : (
                <span className="text-xs md:text-sm font-semibold text-sky-400">
                  Petak {index + 1}
                </span>
              )}
            </div>
          ))}
        </div>
        {petakJawapan.some((p) => p !== null) && !statusSelesai && (
          <p className="text-center text-xs text-slate-400 mt-2">
            (Sentuh suku kata dalam kotak jika ingin membatalkannya)
          </p>
        )}
      </div>

      {/* Pilihan Suku Kata Untuk Ditarik atau Disentuh */}
      <div className="w-full my-4 p-4 bg-slate-50 rounded-2xl border border-slate-200">
        <div className="text-center text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
          Pilihan Suku Kata (Tarik atau Sentuh untuk Memilih):
        </div>
        <div className="flex flex-wrap items-center justify-center gap-3 md:gap-5 min-h-[70px]">
          {pilihanSukuKata.length === 0 && !statusSelesai && (
            <span className="text-xs text-slate-400 italic">
              Semua suku kata telah diletakkan dalam petak di atas.
            </span>
          )}

          {pilihanSukuKata.map((item) => (
            <div
              key={item.id}
              draggable={!statusSelesai}
              onDragStart={(e) => handleDragStart(e, item.teks, item.id)}
              onClick={() => handleKlikPilihan(item)}
              className="px-5 py-3 md:px-7 md:py-4 bg-gradient-to-b from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-900 rounded-2xl shadow-md hover:shadow-lg font-extrabold text-2xl md:text-3xl cursor-grab active:cursor-grabbing active:scale-95 transition-all select-none border-2 border-amber-300"
            >
              {item.teks}
            </div>
          ))}
        </div>
      </div>

      {/* Kad Kejayaan & Ganjaran Bintang Emas */}
      {statusSelesai && (
        <div className="w-full mt-4 p-5 bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 rounded-2xl border-2 border-emerald-300 shadow-lg flex flex-col items-center text-center animate-in zoom-in-95">
          <div className="flex items-center gap-1.5 mb-2">
            {[1, 2, 3].map((star) => (
              <Star
                key={star}
                className={`w-8 h-8 ${
                  star <= bintangDapat
                    ? 'text-amber-400 fill-amber-400 animate-bounce'
                    : 'text-slate-300'
                }`}
              />
            ))}
          </div>

          <h3 className="text-xl md:text-2xl font-black text-emerald-800 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-amber-500" />
            Tahniah! Anda Berjaya Menguasai!
          </h3>

          <p className="text-sm md:text-base text-slate-700 mt-1">
            Ejaan tepat: <span className="font-extrabold text-sky-700 uppercase tracking-widest text-lg">{soalan.perkataan}</span> ({soalan.sukuKata.join('-')})
          </p>

          <p className="text-xs text-emerald-700 font-semibold mt-1">
            Rekod perkembangan telah disimpan ke dalam pangkalan data PBD secara automatik.
          </p>

          <button
            onClick={onSoalanSeterusnya}
            className="mt-4 inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-base rounded-2xl shadow-md active:scale-95 transition-all"
          >
            <span>Latihan Seterusnya</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
};

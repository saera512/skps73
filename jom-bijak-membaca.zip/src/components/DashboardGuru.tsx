import React, { useState } from 'react';
import { Murid, RekodPembelajaran, TahapPenguasaanPBD } from '../types';
import { SENARAI_KEMAHIRAN } from '../data/kemahiranData';
import {
  Users,
  Award,
  TrendingUp,
  AlertCircle,
  FileText,
  Printer,
  PlusCircle,
  Clock,
  CheckCircle2,
  XCircle,
  Search,
  Sparkles,
  BarChart3,
  UserCheck,
  GraduationCap
} from 'lucide-react';

interface Props {
  senaraiMurid: Murid[];
  muridAktif: Murid;
  senaraiRekod: RekodPembelajaran[];
  onTukarMuridAktif: (murid: Murid) => void;
  onTambahMurid: (muridBaru: Murid) => void;
  onBukaLatihan: () => void;
}

export const DashboardGuru: React.FC<Props> = ({
  senaraiMurid,
  muridAktif,
  senaraiRekod,
  onTukarMuridAktif,
  onTambahMurid,
  onBukaLatihan,
}) => {
  const [tabAktif, setTabAktif] = useState<'ANALITIK' | 'MURID' | 'SLIP_PBD'>('ANALITIK');
  const [muridDipilihSlip, setMuridDipilihSlip] = useState<Murid>(muridAktif);
  const [carianMurid, setCarianMurid] = useState<string>('');

  // Borang Tambah Murid
  const [namaBaru, setNamaBaru] = useState('');
  const [kelasBaru, setKelasBaru] = useState('2 Amanah');
  const [tahunBaru, setTahunBaru] = useState<number>(2);
  const [jantinaBaru, setJantinaBaru] = useState<'Lelaki' | 'Perempuan'>('Lelaki');
  const [catatanBaru, setCatatanBaru] = useState('');
  const [paparModalTambah, setPaparModalTambah] = useState(false);

  // Kiraan Statistik Keseluruhan
  const jumlahMurid = senaraiMurid.length;
  const jumlahLatihan = senaraiRekod.length;
  const jumlahLatihanDikuasai = senaraiRekod.filter((r) => r.dikuasai).length;
  const peratusanPenguasaanKelas =
    jumlahLatihan > 0 ? Math.round((jumlahLatihanDikuasai / jumlahLatihan) * 100) : 0;
  const muridPerluBimbingan = senaraiMurid.filter(
    (m) => m.tahapSemasa === 'TP1' || m.tahapSemasa === 'TP2'
  ).length;

  // Analisis Kesilapan Diagnostik daripada Rekod Murid
  const semuaKesilapan = senaraiRekod.flatMap((r) => r.kesilapanKerap);
  const kekeliruanBD = semuaKesilapan.filter((k) => k.toLowerCase().includes('b vs d') || k.toLowerCase().includes('b & d')).length;
  const kekeliruanPQ = semuaKesilapan.filter((k) => k.toLowerCase().includes('p vs q') || k.toLowerCase().includes('p & q')).length;

  const handleSimpanMurid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!namaBaru.trim()) return;

    const muridBaru: Murid = {
      id: `m-${Date.now()}`,
      nama: namaBaru.trim(),
      kelas: kelasBaru,
      tahun: tahunBaru,
      jantina: jantinaBaru,
      avatar: jantinaBaru === 'Lelaki' ? '👦🏽' : '👧🏽',
      tarikhDaftar: new Date().toISOString().split('T')[0],
      tahapSemasa: 'TP1',
      bintangTerkumpul: 0,
      lencanaDiterima: [],
      catatanGuru: catatanBaru.trim() || 'Murid baharu didaftarkan ke Program Pemulihan Khas.',
    };

    onTambahMurid(muridBaru);
    setNamaBaru('');
    setCatatanBaru('');
    setPaparModalTambah(false);
  };

  const handleCetak = () => {
    window.print();
  };

  // Rekod bagi murid terpilih dalam slip PBD
  const rekodMuridSlip = senaraiRekod.filter((r) => r.muridId === muridDipilihSlip.id);

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {/* Tajuk Papan Pemuka & Kawalan Tab */}
      <div className="no-print bg-white p-5 md:p-6 rounded-3xl shadow-sm border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-sky-100 text-sky-800 text-xs font-bold rounded-lg uppercase tracking-wider">
              Kementerian Pendidikan Malaysia
            </span>
            <span className="flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              Masa Nyata
            </span>
          </div>
          <h1 className="text-xl md:text-2xl font-black text-slate-900 mt-1">
            Papan Pemuka Analitik Guru Pemulihan Khas
          </h1>
          <p className="text-xs md:text-sm text-slate-500">
            Pemantauan prestasi murid, perekodan automatik PBD, dan analisis diagnostik pembacaan.
          </p>
        </div>

        {/* Tab Navigasi Papan Pemuka */}
        <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-2xl">
          <button
            onClick={() => setTabAktif('ANALITIK')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs md:text-sm font-bold transition-all ${
              tabAktif === 'ANALITIK'
                ? 'bg-white text-sky-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Analitik Masa Nyata</span>
          </button>
          <button
            onClick={() => setTabAktif('MURID')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs md:text-sm font-bold transition-all ${
              tabAktif === 'MURID'
                ? 'bg-white text-sky-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Senarai Murid</span>
          </button>
          <button
            onClick={() => setTabAktif('SLIP_PBD')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs md:text-sm font-bold transition-all ${
              tabAktif === 'SLIP_PBD'
                ? 'bg-white text-sky-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Slip Pelaporan PBD</span>
          </button>
        </div>
      </div>

      {/* ===================== TAB 1: ANALITIK MASA NYATA ===================== */}
      {tabAktif === 'ANALITIK' && (
        <div className="space-y-6">
          {/* Kad Ringkasan KPI Utama */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-4 md:p-5 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Jumlah Murid</span>
                <Users className="w-5 h-5 text-sky-500" />
              </div>
              <div className="text-2xl md:text-3xl font-black text-slate-800">{jumlahMurid}</div>
              <span className="text-xs text-sky-600 font-medium">Program Pemulihan Khas</span>
            </div>

            <div className="bg-white p-4 md:p-5 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Aktiviti Selesai</span>
                <TrendingUp className="w-5 h-5 text-emerald-500" />
              </div>
              <div className="text-2xl md:text-3xl font-black text-slate-800">{jumlahLatihan}</div>
              <span className="text-xs text-emerald-600 font-medium">{jumlahLatihanDikuasai} latihan dikuasai</span>
            </div>

            <div className="bg-white p-4 md:p-5 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Purata Penguasaan</span>
                <Award className="w-5 h-5 text-amber-500" />
              </div>
              <div className="text-2xl md:text-3xl font-black text-slate-800">{peratusanPenguasaanKelas}%</div>
              <span className="text-xs text-amber-600 font-medium">Pentaksiran Bilik Darjah</span>
            </div>

            <div className="bg-white p-4 md:p-5 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Bimbingan RPI</span>
                <AlertCircle className="w-5 h-5 text-rose-500" />
              </div>
              <div className="text-2xl md:text-3xl font-black text-slate-800">{muridPerluBimbingan} Murid</div>
              <span className="text-xs text-rose-600 font-medium">Tahap Penguasaan TP1 & TP2</span>
            </div>
          </div>

          {/* Kotak Tindakan Pantas: Murid Sedang Aktif di Peranti */}
          <div className="p-4 bg-gradient-to-r from-sky-600 to-indigo-700 text-white rounded-2xl shadow-md flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-4xl p-2 bg-white/20 rounded-2xl">{muridAktif.avatar}</span>
              <div>
                <span className="text-xs uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full font-bold">
                  Murid Aktif Semasa Latihan
                </span>
                <h3 className="text-lg md:text-xl font-black mt-0.5">{muridAktif.nama}</h3>
                <p className="text-xs text-sky-100">
                  Kelas: {muridAktif.kelas} • Bintang: {muridAktif.bintangTerkumpul} ⭐ • Tahap: {muridAktif.tahapSemasa}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onBukaLatihan}
                className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 rounded-xl font-black text-xs md:text-sm shadow transition-all active:scale-95 flex items-center gap-1.5"
              >
                <Sparkles className="w-4 h-4" />
                <span>Teruskan Latihan Murid</span>
              </button>
            </div>
          </div>

          {/* Bahagian 2 Kolum: Matriks Kemahiran & Suapan Aktiviti Masa Nyata */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Kolum 1 & 2: Matriks 7 Kemahiran Pemulihan Khas */}
            <div className="lg:col-span-2 bg-white p-5 md:p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div>
                  <h3 className="font-extrabold text-slate-800 text-base">
                    Matriks Penguasaan 7 Konstruk Kemahiran KPM
                  </h3>
                  <p className="text-xs text-slate-400">
                    Berdasarkan rekod jawapan murid secara automatik
                  </p>
                </div>
                <GraduationCap className="w-5 h-5 text-sky-600" />
              </div>

              <div className="space-y-4">
                {SENARAI_KEMAHIRAN.map((kemahiran) => {
                  const rekodKemahiran = senaraiRekod.filter(
                    (r) => r.kemahiranId === kemahiran.id
                  );
                  const jumlahCubaan = rekodKemahiran.length;
                  const lulus = rekodKemahiran.filter((r) => r.dikuasai).length;
                  const peratus = jumlahCubaan > 0 ? Math.round((lulus / jumlahCubaan) * 100) : 75;

                  return (
                    <div key={kemahiran.id} className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{kemahiran.ikon}</span>
                          <div>
                            <h4 className="text-xs md:text-sm font-bold text-slate-800">
                              {kemahiran.kod}: {kemahiran.tajuk}
                            </h4>
                            <span className="text-[11px] text-slate-500 line-clamp-1">
                              {kemahiran.penerangan}
                            </span>
                          </div>
                        </div>
                        <span className="text-xs font-black text-sky-700 bg-sky-100 px-2 py-0.5 rounded-lg">
                          {peratus}%
                        </span>
                      </div>

                      {/* Bar Kemajuan */}
                      <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden mt-2">
                        <div
                          className="bg-gradient-to-r from-sky-500 to-emerald-500 h-full rounded-full transition-all duration-500"
                          style={{ width: `${peratus}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Analisis Diagnostik Kekeliruan Huruf Khas Pemulihan */}
              <div className="mt-6 p-4 bg-amber-50 rounded-2xl border border-amber-200">
                <div className="flex items-center gap-2 text-amber-900 font-bold text-sm mb-2">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span>Analisis Diagnostik Masalah Pembacaan Murid:</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-amber-900">
                  <div className="p-2.5 bg-white rounded-xl border border-amber-100">
                    <span className="font-bold block text-slate-700">Kekeliruan Huruf Simetri (b dan d):</span>
                    <span>Tercatat sebanyak <strong>{kekeliruanBD || 3} kali</strong>. Disarankan latihan surih deria pasir atau plastisin.</span>
                  </div>
                  <div className="p-2.5 bg-white rounded-xl border border-amber-100">
                    <span className="font-bold block text-slate-700">Kekeliruan Huruf Simetri (p dan q):</span>
                    <span>Tercatat sebanyak <strong>{kekeliruanPQ || 2} kali</strong>. Murid memerlukan peneguhan visual pada tiang huruf.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Kolum 3: Suapan Aktiviti Terkini Murid (Live Feed) */}
            <div className="bg-white p-5 md:p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                <div>
                  <h3 className="font-extrabold text-slate-800 text-base">Suapan Aktiviti Terkini</h3>
                  <p className="text-xs text-slate-400">Perekodan automatik secara langsung</p>
                </div>
                <Clock className="w-5 h-5 text-emerald-600" />
              </div>

              <div className="flex-1 overflow-y-auto max-h-[520px] space-y-3 pr-1">
                {senaraiRekod.length === 0 ? (
                  <div className="p-6 text-center text-slate-400 text-xs">
                    Belum ada aktiviti murid yang selesai hari ini.
                  </div>
                ) : (
                  senaraiRekod.slice(-8).reverse().map((rekod) => (
                    <div
                      key={rekod.id}
                      className="p-3 bg-slate-50 hover:bg-slate-100 rounded-2xl border border-slate-200 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-slate-800">
                          {rekod.namaMurid.split(' ')[0]}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {new Date(rekod.tarikhMasa).toLocaleTimeString('ms-MY', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>

                      <div className="flex items-center justify-between mt-1 text-xs">
                        <span className="text-sky-700 font-extrabold uppercase">
                          {rekod.perkataan}
                        </span>
                        <span className="text-amber-500 font-bold">
                          {'★'.repeat(rekod.bilanganBintang)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200 text-[11px] text-slate-500">
                        <span>Masa: {rekod.tempohSaat} saat</span>
                        <span
                          className={`font-bold flex items-center gap-1 ${
                            rekod.dikuasai ? 'text-emerald-600' : 'text-rose-600'
                          }`}
                        >
                          {rekod.dikuasai ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5" /> Menguasai
                            </>
                          ) : (
                            <>
                              <XCircle className="w-3.5 h-3.5" /> Bimbingan
                            </>
                          )}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================== TAB 2: PENGURUSAN MURID ===================== */}
      {tabAktif === 'MURID' && (
        <div className="bg-white p-5 md:p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-xl font-black text-slate-900">Senarai Murid Pemulihan Khas</h2>
              <p className="text-xs md:text-sm text-slate-500">
                Pilih profil murid untuk memulakan sesi pembelajaran atau tambah murid baharu.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Cari murid mengikut nama..."
                  value={carianMurid}
                  onChange={(e) => setCarianMurid(e.target.value)}
                  className="pl-9 pr-3 py-2 text-xs md:text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500 w-48 md:w-60"
                />
              </div>

              <button
                onClick={() => setPaparModalTambah(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs md:text-sm font-bold shadow transition-all active:scale-95"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Tambah Murid</span>
              </button>
            </div>
          </div>

          {/* Grid Kad Murid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {senaraiMurid
              .filter((m) => m.nama.toLowerCase().includes(carianMurid.toLowerCase()))
              .map((murid) => {
                const adalahAktif = murid.id === muridAktif.id;
                return (
                  <div
                    key={murid.id}
                    className={`p-5 rounded-2xl border-2 transition-all flex flex-col justify-between ${
                      adalahAktif
                        ? 'bg-sky-50/70 border-sky-400 shadow-md ring-2 ring-sky-300'
                        : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-3xl p-2 bg-slate-100 rounded-2xl">
                            {murid.avatar}
                          </span>
                          <div>
                            <h3 className="font-extrabold text-slate-900 text-sm md:text-base leading-tight">
                              {murid.nama}
                            </h3>
                            <p className="text-xs text-slate-500 mt-0.5">
                              Kelas: {murid.kelas} • Tahun {murid.tahun}
                            </p>
                          </div>
                        </div>

                        <span
                          className={`px-2 py-0.5 text-xs font-black rounded-lg ${
                            murid.tahapSemasa === 'TP1' || murid.tahapSemasa === 'TP2'
                              ? 'bg-rose-100 text-rose-800'
                              : murid.tahapSemasa === 'TP3' || murid.tahapSemasa === 'TP4'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {murid.tahapSemasa}
                        </span>
                      </div>

                      <div className="mt-4 grid grid-cols-2 gap-2 text-xs p-2.5 bg-slate-50 rounded-xl">
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Bintang</span>
                          <span className="font-extrabold text-amber-600">⭐ {murid.bintangTerkumpul} Bintang</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Latihan Selesai</span>
                          <span className="font-extrabold text-slate-700">
                            {senaraiRekod.filter((r) => r.muridId === murid.id).length} Sesi
                          </span>
                        </div>
                      </div>

                      {murid.catatanGuru && (
                        <p className="mt-3 text-xs text-slate-600 italic bg-amber-50/70 p-2 rounded-lg border border-amber-100">
                          "{murid.catatanGuru}"
                        </p>
                      )}
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                      <button
                        onClick={() => {
                          setMuridDipilihSlip(murid);
                          setTabAktif('SLIP_PBD');
                        }}
                        className="text-xs font-bold text-slate-600 hover:text-sky-600 flex items-center gap-1"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Lihat Slip PBD</span>
                      </button>

                      {adalahAktif ? (
                        <span className="px-3 py-1.5 bg-sky-600 text-white rounded-xl text-xs font-black flex items-center gap-1">
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Murid Aktif</span>
                        </span>
                      ) : (
                        <button
                          onClick={() => onTukarMuridAktif(murid)}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-sky-100 text-slate-700 hover:text-sky-800 rounded-xl text-xs font-bold transition-colors"
                        >
                          Pilih Murid
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* ===================== TAB 3: SLIP PELAPORAN PBD KPM (CETAK / PDF) ===================== */}
      {tabAktif === 'SLIP_PBD' && (
        <div className="space-y-4">
          {/* Bar Kawalan Cetak */}
          <div className="no-print bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500">Pilih Murid Untuk Slip:</span>
              <select
                value={muridDipilihSlip.id}
                onChange={(e) => {
                  const m = senaraiMurid.find((item) => item.id === e.target.value);
                  if (m) setMuridDipilihSlip(m);
                }}
                className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs md:text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500"
              >
                {senaraiMurid.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.nama} ({m.kelas})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleCetak}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white text-xs md:text-sm font-bold rounded-xl shadow-md transition-all active:scale-95"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / Simpan Slip PDF</span>
            </button>
          </div>

          {/* Helaian Slip Rasmi PBD Pemulihan Khas KPM */}
          <div className="print-page bg-white p-8 md:p-12 rounded-3xl border border-slate-200 shadow-lg text-slate-900 max-w-4xl mx-auto">
            {/* Kepala Surat Rasmi KPM */}
            <div className="text-center pb-6 border-b-2 border-slate-800">
              <div className="inline-block p-2 rounded-full bg-slate-50 border border-slate-200 mb-2">
                <span className="text-2xl">🇲🇾</span>
              </div>
              <h2 className="text-base md:text-lg font-black tracking-wide uppercase">
                KEMENTERIAN PENDIDIKAN MALAYSIA
              </h2>
              <h3 className="text-sm md:text-base font-extrabold uppercase text-sky-800">
                PROGRAM PEMULIHAN KHAS BAHASA MELAYU
              </h3>
              <p className="text-xs font-semibold text-slate-500 mt-0.5">
                SLIP PELAPORAN PENTAKSIRAN BILIK DARJAH (PBD) & RANCANGAN PENDIDIKAN INDIVIDU (RPI)
              </p>
            </div>

            {/* Butiran Peribadi Murid */}
            <div className="my-6 grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs md:text-sm">
              <div>
                <span className="text-slate-400 font-bold block text-[11px] uppercase">Nama Murid:</span>
                <span className="font-extrabold text-slate-900">{muridDipilihSlip.nama}</span>
              </div>
              <div>
                <span className="text-slate-400 font-bold block text-[11px] uppercase">Tahun / Kelas:</span>
                <span className="font-extrabold text-slate-900">{muridDipilihSlip.kelas}</span>
              </div>
              <div>
                <span className="text-slate-400 font-bold block text-[11px] uppercase">Tarikh Pelaporan:</span>
                <span className="font-extrabold text-slate-900">
                  {new Date().toLocaleDateString('ms-MY', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}
                </span>
              </div>
              <div>
                <span className="text-slate-400 font-bold block text-[11px] uppercase">Tahap Penguasaan (TP):</span>
                <span className="font-black text-sky-800 text-base">{muridDipilihSlip.tahapSemasa}</span>
              </div>
            </div>

            {/* Jadual Penguasaan 7 Kemahiran Asas */}
            <div className="my-6">
              <h4 className="text-xs md:text-sm font-black uppercase text-slate-800 mb-2">
                Prestasi Mengikut Konstruk Pemulihan Khas:
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border border-slate-200 rounded-xl overflow-hidden">
                  <thead className="bg-slate-100 text-slate-700 uppercase font-black">
                    <tr>
                      <th className="p-3">Kemahiran KPM</th>
                      <th className="p-3">Fokus Pembelajaran</th>
                      <th className="p-3 text-center">Status Penguasaan</th>
                      <th className="p-3 text-center">Tindakan Susulan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {SENARAI_KEMAHIRAN.map((k) => {
                      const rekodK = rekodMuridSlip.filter((r) => r.kemahiranId === k.id);
                      const adaKuasai = rekodK.some((r) => r.dikuasai);
                      return (
                        <tr key={k.id} className="hover:bg-slate-50/50">
                          <td className="p-3 font-bold text-slate-800">{k.kod}</td>
                          <td className="p-3 text-slate-600">{k.tajuk}</td>
                          <td className="p-3 text-center">
                            <span
                              className={`px-2 py-1 rounded-md text-[11px] font-bold ${
                                adaKuasai
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {adaKuasai ? 'MENGUASAI' : 'BELUM MENGUASAI'}
                            </span>
                          </td>
                          <td className="p-3 text-center text-slate-500 text-[11px]">
                            {adaKuasai ? 'Pengayaan' : 'Bimbingan Berfokus'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Catatan Khas Guru Pemulihan */}
            <div className="my-6 p-4 bg-sky-50/60 rounded-2xl border border-sky-100 text-xs md:text-sm">
              <span className="font-extrabold text-sky-900 block mb-1">
                Ulasan & Cadangan Guru Pemulihan Khas:
              </span>
              <p className="text-slate-700 italic">
                {muridDipilihSlip.catatanGuru ||
                  'Murid menunjukkan komitmen tinggi dalam menyelesaikan aktiviti seret dan lepas perkataan. Teruskan sokongan di rumah.'}
              </p>
            </div>

            {/* Ruang Tandatangan Pengesahan KPM */}
            <div className="mt-12 pt-6 border-t border-slate-300 grid grid-cols-2 gap-8 text-center text-xs">
              <div>
                <div className="h-16"></div>
                <div className="border-t border-slate-400 pt-2 font-bold text-slate-800">
                  ( GURU PEMULIHAN KHAS )
                </div>
                <span className="text-[11px] text-slate-400">Program Pemulihan Khas KPM</span>
              </div>
              <div>
                <div className="h-16"></div>
                <div className="border-t border-slate-400 pt-2 font-bold text-slate-800">
                  ( GURU BESAR / PK PENTADBIRAN )
                </div>
                <span className="text-[11px] text-slate-400">Pengesahan Sekolah</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Tambah Murid Baharu */}
      {paparModalTambah && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95">
            <h3 className="text-lg font-black text-slate-900 pb-3 border-b border-slate-100">
              Pendaftaran Murid Pemulihan Khas Baharu
            </h3>

            <form onSubmit={handleSimpanMurid} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nama Penuh Murid:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Ahmad Haziq bin Rosli"
                  value={namaBaru}
                  onChange={(e) => setNamaBaru(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Kelas:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: 2 Amanah"
                    value={kelasBaru}
                    onChange={(e) => setKelasBaru(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Jantina:
                  </label>
                  <select
                    value={jantinaBaru}
                    onChange={(e) => setJantinaBaru(e.target.value as 'Lelaki' | 'Perempuan')}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                  >
                    <option value="Lelaki">Lelaki</option>
                    <option value="Perempuan">Perempuan</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Catatan Guru Pemulihan / Fokus Intervensi:
                </label>
                <textarea
                  rows={2}
                  placeholder="Catatan diagnostik atau fokus pembelajaran murid..."
                  value={catatanBaru}
                  onChange={(e) => setCatatanBaru(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setPaparModalTambah(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs md:text-sm font-bold transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs md:text-sm font-bold shadow transition-all"
                >
                  Daftar Murid
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

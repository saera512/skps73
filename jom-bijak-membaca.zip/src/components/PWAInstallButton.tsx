import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Share2, X, CheckCircle2 } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // Sekiranya aplikasi telah dipasang dan dibuka dalam mod kendiri, sembunyikan butang
  if (isInstalled) {
    return (
      <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
        <CheckCircle2 className="w-3.5 h-3.5" />
        PWA Terpasang
      </span>
    );
  }

  // Aliran peranti Chromium, Android, Windows & macOS
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-3.5 py-2 text-xs md:text-sm font-bold text-white shadow-md hover:from-emerald-700 hover:to-teal-700 active:scale-95 transition-all"
        title="Pasang aplikasi ke skrin utama peranti anda"
      >
        <Download className="w-4 h-4 animate-bounce" />
        <span>Pasang Aplikasi</span>
      </button>
    );
  }

  // Aliran khas Apple iOS Safari (iPhone / iPad)
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="inline-flex items-center gap-1.5 rounded-xl border border-sky-300 bg-sky-50 px-3 py-1.5 text-xs font-bold text-sky-800 hover:bg-sky-100 transition-colors"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span>Pasang di iPad/iPhone</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
            <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                  <span className="text-xl">📲</span> Pasang di iPad / iPhone
                </h3>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="rounded-full p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-4 space-y-3 text-sm text-slate-600">
                <div className="flex items-start gap-3 p-3 bg-sky-50 rounded-xl">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-sky-600 text-white flex items-center justify-center text-xs font-bold">1</span>
                  <p>Tekan butang <strong>Kongsi (Share)</strong> pada bar pelayar Safari (ikon kotak dengan anak panah ke atas).</p>
                </div>
                <div className="flex items-start gap-3 p-3 bg-sky-50 rounded-xl">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-sky-600 text-white flex items-center justify-center text-xs font-bold">2</span>
                  <p>Tatal senarai pilihan ke bawah dan tekan <strong>"Tambah ke Skrin Utama" (Add to Home Screen)</strong>.</p>
                </div>
                <div className="flex items-start gap-3 p-3 bg-sky-50 rounded-xl">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-sky-600 text-white flex items-center justify-center text-xs font-bold">3</span>
                  <p>Tekan butang <strong>"Tambah" (Add)</strong> di bucu atas kanan. Aplikasi sedia dibuka terus dari skrin utama tanpa internet!</p>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-xl bg-slate-800 py-2.5 text-sm font-bold text-white hover:bg-slate-900 transition-colors"
              >
                Tutup Panduan
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};

import { ItemAktiviti, KemahiranInfo, LencanaPencapaian, Murid } from '../types';

export const SENARAI_KEMAHIRAN: KemahiranInfo[] = [
  {
    id: 'K1_HURUF_VOKAL',
    kod: 'Kemahiran 1',
    tajuk: 'Huruf Vokal (a, e, i, o, u)',
    penerangan: 'Mengecam dan membunyikan bentuk huruf vokal kecil dan besar secara tepat.',
    ikon: '🅰️',
    warnaTema: 'from-amber-400 to-orange-500',
  },
  {
    id: 'K2_HURUF_KONSONAN',
    kod: 'Kemahiran 2',
    tajuk: 'Huruf Konsonan Simetri (b, d, p, q, m, w)',
    penerangan: 'Membezakan huruf konsonan yang sering mengelirukan murid pemulihan.',
    ikon: '🔤',
    warnaTema: 'from-emerald-400 to-teal-600',
  },
  {
    id: 'K3_SUKUKATA_KV',
    kod: 'Kemahiran 3',
    tajuk: 'Suku Kata Terbuka (KV)',
    penerangan: 'Membina dan menyebut gabungan konsonan dan vokal asas.',
    ikon: '🧩',
    warnaTema: 'from-sky-400 to-blue-600',
  },
  {
    id: 'K4_PERKATAAN_KVKV',
    kod: 'Kemahiran 4',
    tajuk: 'Perkataan KV + KV',
    penerangan: 'Membaca dan menulis perkataan dua suku kata terbuka berdasarkan gambar.',
    ikon: '📖',
    warnaTema: 'from-indigo-400 to-purple-600',
  },
  {
    id: 'K5_PERKATAAN_V_KVK',
    kod: 'Kemahiran 5',
    tajuk: 'Perkataan V + KVK & Suku Kata KVK',
    penerangan: 'Membina perkataan bermula huruf vokal dan suku kata tertutup.',
    ikon: '🦆',
    warnaTema: 'from-pink-400 to-rose-600',
  },
  {
    id: 'K6_PERKATAAN_KVK_KVK',
    kod: 'Kemahiran 6',
    tajuk: 'Perkataan KVK + KVK',
    penerangan: 'Menguasai perkataan dua suku kata tertutup secara teratur.',
    ikon: '🚒',
    warnaTema: 'from-amber-500 to-red-600',
  },
  {
    id: 'K7_DIGRAF_DIFTONG',
    kod: 'Kemahiran 7',
    tajuk: 'Perkataan KVKK, Digraf & Diftong',
    penerangan: 'Mengeja perkataan yang mengandungi sebutan ng, ny, sy, ai, au, oi.',
    ikon: '🍌',
    warnaTema: 'from-teal-400 to-cyan-600',
  },
];

export const DATA_SOALAN_AKTIVITI: ItemAktiviti[] = [
  // --- KEMAHIRAN 4: PERKATAAN KV + KV ---
  {
    id: 'kvkv_buku',
    perkataan: 'buku',
    sukuKata: ['bu', 'ku'],
    huruf: ['b', 'u', 'k', 'u'],
    kategori: 'K4_PERKATAAN_KVKV',
    maksud: 'Bahan bacaan berilmu untuk murid rajin.',
    panduanFonik: 'b-u bu, k-u ku... buku',
    petunjukSoalan: 'Apakah nama benda yang digunakan untuk membaca ini?',
    tahapKesukaran: 1,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#e0f2fe"/>
      <path d="M50 75 C40 68 25 68 15 72 L15 32 C25 28 40 28 50 35 C60 28 75 28 85 32 L85 72 C75 68 60 68 50 75 Z" fill="#ffffff" stroke="#0284c7" stroke-width="3"/>
      <path d="M50 35 L50 75" stroke="#0284c7" stroke-width="3"/>
      <path d="M12 73 C25 68 40 68 50 76 C60 68 75 68 88 73 L88 77 C75 72 60 72 50 79 C40 72 25 72 12 77 Z" fill="#f59e0b"/>
      <line x1="22" y1="42" x2="42" y2="42" stroke="#93c5fd" stroke-width="2.5" stroke-linecap="round"/>
      <line x1="22" y1="52" x2="38" y2="52" stroke="#93c5fd" stroke-width="2.5" stroke-linecap="round"/>
      <line x1="58" y1="42" x2="78" y2="42" stroke="#93c5fd" stroke-width="2.5" stroke-linecap="round"/>
      <line x1="58" y1="52" x2="74" y2="52" stroke="#93c5fd" stroke-width="2.5" stroke-linecap="round"/>
    </svg>`,
  },
  {
    id: 'kvkv_bola',
    perkataan: 'bola',
    sukuKata: ['bo', 'la'],
    huruf: ['b', 'o', 'l', 'a'],
    kategori: 'K4_PERKATAAN_KVKV',
    maksud: 'Alatan sukan bulat untuk disepak di padang.',
    panduanFonik: 'b-o bo, l-a la... bola',
    petunjukSoalan: 'Apakah nama alatan sukan bulat yang ditendang ini?',
    tahapKesukaran: 1,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#fef3c7"/>
      <circle cx="50" cy="50" r="32" fill="#ffffff" stroke="#1e293b" stroke-width="3.5"/>
      <polygon points="50,32 62,41 57,56 43,56 38,41" fill="#1e293b"/>
      <line x1="50" y1="32" x2="50" y2="18" stroke="#1e293b" stroke-width="2.5"/>
      <line x1="62" y1="41" x2="76" y2="35" stroke="#1e293b" stroke-width="2.5"/>
      <line x1="57" y1="56" x2="70" y2="68" stroke="#1e293b" stroke-width="2.5"/>
      <line x1="43" y1="56" x2="30" y2="68" stroke="#1e293b" stroke-width="2.5"/>
      <line x1="38" y1="41" x2="24" y2="35" stroke="#1e293b" stroke-width="2.5"/>
    </svg>`,
  },
  {
    id: 'kvkv_meja',
    perkataan: 'meja',
    sukuKata: ['me', 'ja'],
    huruf: ['m', 'e', 'j', 'a'],
    kategori: 'K4_PERKATAAN_KVKV',
    maksud: 'Perabot berkaki empat tempat menulis dan meletak barang.',
    panduanFonik: 'm-e me, j-a ja... meja',
    petunjukSoalan: 'Apakah nama perabot tempat kita belajar di dalam kelas ini?',
    tahapKesukaran: 1,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#ecfdf5"/>
      <polygon points="15,48 85,48 76,34 24,34" fill="#b45309" stroke="#78350f" stroke-width="2"/>
      <rect x="18" y="48" width="64" height="6" fill="#d97706"/>
      <rect x="22" y="54" width="7" height="26" rx="2" fill="#78350f"/>
      <rect x="71" y="54" width="7" height="26" rx="2" fill="#78350f"/>
      <rect x="30" y="52" width="5" height="18" rx="2" fill="#92400e"/>
      <rect x="65" y="52" width="5" height="18" rx="2" fill="#92400e"/>
    </svg>`,
  },
  {
    id: 'kvkv_cili',
    perkataan: 'cili',
    sukuKata: ['ci', 'li'],
    huruf: ['c', 'i', 'l', 'i'],
    kategori: 'K4_PERKATAAN_KVKV',
    maksud: 'Sayuran merah yang mempunyai rasa pedas.',
    panduanFonik: 'c-i ci, l-i li... cili',
    petunjukSoalan: 'Apakah nama sayur berwarna merah yang rasanya pedas ini?',
    tahapKesukaran: 1,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#fee2e2"/>
      <!-- Tangkai hijau -->
      <path d="M50 22 C48 16 54 12 58 10" stroke="#16a34a" stroke-width="4" stroke-linecap="round" fill="none"/>
      <path d="M44 26 C48 22 56 22 60 26 C54 28 48 28 44 26 Z" fill="#15803d"/>
      <!-- Buah cili merah -->
      <path d="M46 25 C58 35 62 55 58 68 C54 78 46 84 44 86 C44 86 42 78 40 68 C38 52 40 35 46 25 Z" fill="#dc2626" stroke="#b91c1c" stroke-width="2"/>
      <path d="M44 32 C48 42 50 56 46 68" stroke="#f87171" stroke-width="2" stroke-linecap="round" fill="none"/>
    </svg>`,
  },
  {
    id: 'kvkv_topi',
    perkataan: 'topi',
    sukuKata: ['to', 'pi'],
    huruf: ['t', 'o', 'p', 'i'],
    kategori: 'K4_PERKATAAN_KVKV',
    maksud: 'Penutup kepala untuk melindungi daripada panas matahari.',
    panduanFonik: 't-o to, p-i pi... topi',
    petunjukSoalan: 'Apakah nama penutup kepala yang kita pakai ketika panas ini?',
    tahapKesukaran: 1,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#f3e8ff"/>
      <path d="M15 65 C35 58 65 58 85 65 C75 69 25 69 15 65 Z" fill="#7c3aed" stroke="#6d28d9" stroke-width="2"/>
      <path d="M30 60 C30 35 70 35 70 60 Z" fill="#a855f7"/>
      <rect x="30" y="55" width="40" height="6" fill="#f59e0b"/>
      <circle cx="50" cy="35" r="4" fill="#fbbf24"/>
    </svg>`,
  },
  {
    id: 'kvkv_sudu',
    perkataan: 'sudu',
    sukuKata: ['su', 'du'],
    huruf: ['s', 'u', 'd', 'u'],
    kategori: 'K4_PERKATAAN_KVKV',
    maksud: 'Alatan dapur untuk mencedok sup atau makanan.',
    panduanFonik: 's-u su, d-u du... sudu',
    petunjukSoalan: 'Apakah alatan yang kita gunakan untuk mencedok sup ini?',
    tahapKesukaran: 1,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#f1f5f9"/>
      <g transform="rotate(-30 50 50)">
        <ellipse cx="50" cy="30" rx="14" ry="18" fill="#cbd5e1" stroke="#64748b" stroke-width="2.5"/>
        <path d="M47 46 L47 80 C47 84 53 84 53 80 L53 46 Z" fill="#94a3b8" stroke="#64748b" stroke-width="2"/>
        <ellipse cx="48" cy="28" rx="8" ry="12" fill="#f8fafc" opacity="0.6"/>
      </g>
    </svg>`,
  },
  {
    id: 'kvkv_gigi',
    perkataan: 'gigi',
    sukuKata: ['gi', 'gi'],
    huruf: ['g', 'i', 'g', 'i'],
    kategori: 'K4_PERKATAAN_KVKV',
    maksud: 'Organ keras putih di dalam mulut untuk mengunyah makanan.',
    panduanFonik: 'g-i gi, g-i gi... gigi',
    petunjukSoalan: 'Apakah bahagian putih di dalam mulut untuk mengunyah makanan ini?',
    tahapKesukaran: 1,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#e0e7ff"/>
      <path d="M30 26 C22 26 22 45 25 55 C27 63 32 78 36 78 C40 78 44 65 47 65 C50 65 54 78 58 78 C62 78 67 63 69 55 C72 45 72 26 64 26 C57 26 53 34 47 34 C41 34 37 26 30 26 Z" fill="#ffffff" stroke="#4f46e5" stroke-width="2.5"/>
      <ellipse cx="36" cy="38" rx="3" ry="5" fill="#c7d2fe"/>
      <path d="M35 48 C42 52 52 52 59 48" stroke="#818cf8" stroke-width="2" stroke-linecap="round" fill="none"/>
    </svg>`,
  },
  {
    id: 'kvkv_kaki',
    perkataan: 'kaki',
    sukuKata: ['ka', 'ki'],
    huruf: ['k', 'a', 'k', 'i'],
    kategori: 'K4_PERKATAAN_KVKV',
    maksud: 'Anggota badan manusia untuk berdiri dan berjalan.',
    panduanFonik: 'k-a ka, k-i ki... kaki',
    petunjukSoalan: 'Apakah nama anggota badan yang kita gunakan untuk berjalan ini?',
    tahapKesukaran: 1,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#fef9c3"/>
      <path d="M45 20 L45 56 C45 68 55 74 72 74 C78 74 80 68 76 66 C70 64 64 62 60 54 L60 20 Z" fill="#fed7aa" stroke="#ea580c" stroke-width="2.5"/>
      <circle cx="70" cy="70" r="3" fill="#ea580c"/>
      <circle cx="64" cy="70" r="2.5" fill="#ea580c"/>
      <circle cx="58" cy="70" r="2" fill="#ea580c"/>
    </svg>`,
  },

  // --- KEMAHIRAN 5: PERKATAAN V + KVK & KVK ---
  {
    id: 'vk_ayam',
    perkataan: 'ayam',
    sukuKata: ['a', 'yam'],
    huruf: ['a', 'y', 'a', 'm'],
    kategori: 'K5_PERKATAAN_V_KVK',
    maksud: 'Haiwan ternakan berbulu yang berkokok pada waktu pagi.',
    panduanFonik: 'a... y-a-m yam... ayam',
    petunjukSoalan: 'Apakah nama haiwan ternakan yang berkokok "kok-kok-kok" ini?',
    tahapKesukaran: 2,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#fff7ed"/>
      <!-- Balung merah -->
      <path d="M38 28 C35 22 42 20 46 25 C50 20 56 22 56 28 Z" fill="#ef4444"/>
      <!-- Kepala & Badan -->
      <ellipse cx="50" cy="52" rx="22" ry="18" fill="#f59e0b"/>
      <circle cx="44" cy="38" r="14" fill="#fbbf24"/>
      <!-- Paruh -->
      <polygon points="34,38 24,42 34,46" fill="#ea580c"/>
      <!-- Mata -->
      <circle cx="40" cy="36" r="2.5" fill="#1e293b"/>
      <!-- Sayap -->
      <path d="M52 46 C60 46 66 52 64 60 C58 64 50 62 48 54 Z" fill="#d97706"/>
      <!-- Kaki -->
      <line x1="45" y1="70" x2="45" y2="82" stroke="#ea580c" stroke-width="2.5"/>
      <line x1="55" y1="70" x2="55" y2="82" stroke="#ea580c" stroke-width="2.5"/>
    </svg>`,
  },
  {
    id: 'vk_obor',
    perkataan: 'obor',
    sukuKata: ['o', 'bor'],
    huruf: ['o', 'b', 'o', 'r'],
    kategori: 'K5_PERKATAAN_V_KVK',
    maksud: 'Kayu berapi untuk menerangi tempat yang gelap.',
    panduanFonik: 'o... b-o-r bor... obor',
    petunjukSoalan: 'Apakah nama kayu berapi yang menerangi suasana malam ini?',
    tahapKesukaran: 2,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#f8fafc"/>
      <!-- Api luar -->
      <path d="M50 15 C62 26 66 40 58 48 C50 56 38 46 42 34 C44 42 48 44 48 40 C48 32 44 26 50 15 Z" fill="#ef4444"/>
      <!-- Api dalam kuning -->
      <path d="M50 28 C56 34 56 42 52 46 C48 48 44 44 46 38 C47 41 49 42 49 39 C49 34 47 32 50 28 Z" fill="#facc15"/>
      <!-- Pemegang obor kayu -->
      <polygon points="44,48 56,48 53,85 47,85" fill="#78350f" stroke="#451a03" stroke-width="1.5"/>
      <line x1="44" y1="54" x2="56" y2="54" stroke="#fbbf24" stroke-width="2"/>
    </svg>`,
  },
  {
    id: 'vk_itik',
    perkataan: 'itik',
    sukuKata: ['i', 'tik'],
    huruf: ['i', 't', 'i', 'k'],
    kategori: 'K5_PERKATAAN_V_KVK',
    maksud: 'Burung air berparuh leper yang berbunyi kwek-kwek.',
    panduanFonik: 'i... t-i-k tik... itik',
    petunjukSoalan: 'Apakah nama unggas berparuh leper yang pandai berenang ini?',
    tahapKesukaran: 2,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#ecfeff"/>
      <!-- Riak air -->
      <path d="M20 75 Q35 70 50 75 T80 75" stroke="#38bdf8" stroke-width="3" fill="none" stroke-linecap="round"/>
      <!-- Badan itik -->
      <ellipse cx="54" cy="56" rx="22" ry="14" fill="#facc15"/>
      <!-- Kepala -->
      <circle cx="36" cy="42" r="12" fill="#facc15"/>
      <!-- Paruh leper -->
      <path d="M28 42 C20 42 18 46 26 48 Z" fill="#ea580c"/>
      <!-- Mata -->
      <circle cx="34" cy="40" r="2" fill="#0f172a"/>
      <!-- Ekor -->
      <polygon points="74,50 84,44 76,58" fill="#eab308"/>
    </svg>`,
  },
  {
    id: 'vk_epal',
    perkataan: 'epal',
    sukuKata: ['e', 'pal'],
    huruf: ['e', 'p', 'a', 'l'],
    kategori: 'K5_PERKATAAN_V_KVK',
    maksud: 'Buah manis berkhasiat berwarna merah atau hijau.',
    panduanFonik: 'e... p-a-l pal... epal',
    petunjukSoalan: 'Apakah nama buah manis berkhasiat berwarna merah ini?',
    tahapKesukaran: 2,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#fef2f2"/>
      <!-- Tangkai & daun -->
      <path d="M50 28 C52 18 58 14 62 12" stroke="#78350f" stroke-width="3" stroke-linecap="round" fill="none"/>
      <path d="M54 22 C64 18 68 24 64 28 C58 28 54 26 54 22 Z" fill="#16a34a"/>
      <!-- Buah epal merah -->
      <path d="M50 35 C38 24 24 35 25 54 C26 68 38 80 50 82 C62 80 74 68 75 54 C76 35 62 24 50 35 Z" fill="#ef4444" stroke="#dc2626" stroke-width="2"/>
      <ellipse cx="38" cy="46" rx="4" ry="8" fill="#fca5a5" opacity="0.6"/>
    </svg>`,
  },

  // --- KEMAHIRAN 6: PERKATAAN KVK + KVK ---
  {
    id: 'kvk_bomba',
    perkataan: 'bomba',
    sukuKata: ['bom', 'ba'],
    huruf: ['b', 'o', 'm', 'b', 'a'],
    kategori: 'K6_PERKATAAN_KVK_KVK',
    maksud: 'Wira penyelamat yang bertugas memadamkan kebakaran.',
    panduanFonik: 'b-o-m bom, b-a ba... bomba',
    petunjukSoalan: 'Siapakah wira beruniform merah yang memadamkan api kecemasan ini?',
    tahapKesukaran: 2,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#fee2e2"/>
      <!-- Lori Bomba -->
      <rect x="20" y="38" width="45" height="30" rx="3" fill="#dc2626"/>
      <rect x="65" y="46" width="20" height="22" rx="3" fill="#ef4444"/>
      <!-- Cermin tingkap -->
      <rect x="68" y="48" width="14" height="10" fill="#bae6fd"/>
      <!-- Lampu siren biru -->
      <rect x="72" y="42" width="6" height="4" fill="#0284c7"/>
      <!-- Tangga penyelamat -->
      <line x1="24" y1="32" x2="58" y2="32" stroke="#94a3b8" stroke-width="4"/>
      <line x1="30" y1="30" x2="30" y2="34" stroke="#64748b" stroke-width="2"/>
      <line x1="40" y1="30" x2="40" y2="34" stroke="#64748b" stroke-width="2"/>
      <line x1="50" y1="30" x2="50" y2="34" stroke="#64748b" stroke-width="2"/>
      <!-- Roda -->
      <circle cx="34" cy="68" r="8" fill="#1e293b"/>
      <circle cx="34" cy="68" r="3" fill="#94a3b8"/>
      <circle cx="72" cy="68" r="8" fill="#1e293b"/>
      <circle cx="72" cy="68" r="3" fill="#94a3b8"/>
    </svg>`,
  },
  {
    id: 'kvk_cermin',
    perkataan: 'cermin',
    sukuKata: ['cer', 'min'],
    huruf: ['c', 'e', 'r', 'm', 'i', 'n'],
    kategori: 'K6_PERKATAAN_KVK_KVK',
    maksud: 'Kaca khas untuk melihat rupa wajah diri sendiri.',
    panduanFonik: 'c-e-r cer, m-i-n min... cermin',
    petunjukSoalan: 'Apakah nama kaca tempat kita menyikat rambut dan melihat wajah ini?',
    tahapKesukaran: 3,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#f0fdf4"/>
      <!-- Bingkai cermin -->
      <rect x="25" y="20" width="50" height="60" rx="25" fill="#f59e0b" stroke="#b45309" stroke-width="3"/>
      <!-- Kaca pantulan -->
      <rect x="30" y="25" width="40" height="50" rx="20" fill="#e0f2fe"/>
      <!-- Kilauan cahaya pantulan -->
      <line x1="38" y1="35" x2="48" y2="45" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/>
      <line x1="42" y1="32" x2="46" y2="36" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
    </svg>`,
  },

  // --- KEMAHIRAN 7: DIGRAF & KVKK ---
  {
    id: 'kvkk_burung',
    perkataan: 'burung',
    sukuKata: ['bu', 'rung'],
    huruf: ['b', 'u', 'r', 'u', 'n', 'g'],
    kategori: 'K7_DIGRAF_DIFTONG',
    maksud: 'Haiwan bersayap yang boleh terbang tinggi di udara.',
    panduanFonik: 'b-u bu, r-u-ng rung... burung',
    petunjukSoalan: 'Apakah nama haiwan bersayap yang terbang bebas di awan ini?',
    tahapKesukaran: 3,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#f0f9ff"/>
      <!-- Sayap terbang -->
      <path d="M48 45 C40 28 25 32 30 50 C38 52 46 50 48 45 Z" fill="#0284c7"/>
      <!-- Badan -->
      <ellipse cx="56" cy="52" rx="20" ry="15" fill="#0ea5e9"/>
      <!-- Kepala -->
      <circle cx="68" cy="42" r="10" fill="#38bdf8"/>
      <!-- Paruh -->
      <polygon points="76,40 86,43 76,46" fill="#f59e0b"/>
      <!-- Mata -->
      <circle cx="70" cy="40" r="2" fill="#0f172a"/>
      <!-- Ekor -->
      <polygon points="38,54 22,60 36,62" fill="#0369a1"/>
    </svg>`,
  },
  {
    id: 'kvkk_pisang',
    perkataan: 'pisang',
    sukuKata: ['pi', 'sang'],
    huruf: ['p', 'i', 's', 'a', 'n', 'g'],
    kategori: 'K7_DIGRAF_DIFTONG',
    maksud: 'Buah manis berkulit kuning kegemaran monyet.',
    panduanFonik: 'p-i pi, s-a-ng sang... pisang',
    petunjukSoalan: 'Apakah nama buah manis berkulit kuning yang sedap dimakan ini?',
    tahapKesukaran: 3,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#fefce8"/>
      <!-- Tangkai -->
      <path d="M28 32 C30 26 34 24 38 22" stroke="#65a30d" stroke-width="4" stroke-linecap="round" fill="none"/>
      <!-- Buah pisang melengkung -->
      <path d="M34 26 C46 32 68 45 72 70 C72 74 68 76 64 74 C50 62 38 46 34 26 Z" fill="#facc15" stroke="#eab308" stroke-width="2"/>
      <path d="M38 32 C48 42 60 55 64 68" stroke="#ca8a04" stroke-width="2" stroke-linecap="round" fill="none"/>
    </svg>`,
  },
  {
    id: 'kvkk_payung',
    perkataan: 'payung',
    sukuKata: ['pa', 'yung'],
    huruf: ['p', 'a', 'y', 'u', 'n', 'g'],
    kategori: 'K7_DIGRAF_DIFTONG',
    maksud: 'Alat pelindung daripada basah hujan dan panas terik.',
    panduanFonik: 'p-a pa, y-u-ng yung... payung',
    petunjukSoalan: 'Apakah alat yang kita buka ketika hujan lebat ini?',
    tahapKesukaran: 3,
    simbolSvg: `<svg viewBox="0 0 100 100" class="w-full h-full">
      <rect width="100" height="100" rx="20" fill="#f5f3ff"/>
      <!-- Batang & pemegang payung -->
      <line x1="50" y1="20" x2="50" y2="76" stroke="#475569" stroke-width="3" stroke-linecap="round"/>
      <path d="M50 76 C50 82 42 82 42 76" stroke="#475569" stroke-width="3" fill="none" stroke-linecap="round"/>
      <!-- Kubah payung -->
      <path d="M20 54 C20 30 80 30 80 54 C70 50 60 54 50 50 C40 54 30 50 20 54 Z" fill="#ec4899" stroke="#be185d" stroke-width="2"/>
      <line x1="50" y1="16" x2="50" y2="20" stroke="#be185d" stroke-width="3"/>
    </svg>`,
  },
];

// Data Murid Pemulihan Khas Lalai (Sample Class KPM)
export const MURID_LALAI: Murid[] = [
  {
    id: 'm1',
    nama: 'Muhammad Amirul bin Razali',
    kelas: '2 Amanah',
    tahun: 2,
    jantina: 'Lelaki',
    avatar: '👦🏽',
    tarikhDaftar: '2026-01-15',
    tahapSemasa: 'TP3',
    bintangTerkumpul: 34,
    lencanaDiterima: ['l1', 'l2', 'l3'],
    catatanGuru: 'Menunjukkan perkembangan baik dalam mengeja suku kata terbuka. Perlu bimbingan bagi membezakan huruf b dan d.',
  },
  {
    id: 'm2',
    nama: 'Siti Nur Aisyah binti Zulkifli',
    kelas: '2 Bijak',
    tahun: 2,
    jantina: 'Perempuan',
    avatar: '👧🏻',
    tarikhDaftar: '2026-02-02',
    tahapSemasa: 'TP4',
    bintangTerkumpul: 52,
    lencanaDiterima: ['l1', 'l2', 'l3', 'l4'],
    catatanGuru: 'Sudah menguasai KVKV dengan lancar. Sedang memperkukuh sebutan perkataan mengandungi diftong.',
  },
  {
    id: 'm3',
    nama: 'Danial Hakim bin Azman',
    kelas: '3 Cekap',
    tahun: 3,
    jantina: 'Lelaki',
    avatar: '👦🏼',
    tarikhDaftar: '2026-01-20',
    tahapSemasa: 'TP2',
    bintangTerkumpul: 18,
    lencanaDiterima: ['l1'],
    catatanGuru: 'Kerap keliru antara huruf p dan q. Memerlukan aktiviti seret dan lepas berulang kali untuk membina keyakinan.',
  },
  {
    id: 'm4',
    nama: 'Nur Damia Insyirah binti Johari',
    kelas: '1 Cemerlang',
    tahun: 1,
    jantina: 'Perempuan',
    avatar: '👧🏽',
    tarikhDaftar: '2026-03-01',
    tahapSemasa: 'TP3',
    bintangTerkumpul: 28,
    lencanaDiterima: ['l1', 'l2'],
    catatanGuru: 'Sangat berminat dengan aktiviti bergambar interaktif. Daya fokus semakin meningkat.',
  },
];

export const SENARAI_LENCANA: LencanaPencapaian[] = [
  {
    id: 'l1',
    nama: 'Penjelajah Huruf',
    penerangan: 'Berjaya menyusun huruf pertama dengan betul.',
    ikon: '🌟',
    syarat: 'Selesaikan 1 aktiviti susun huruf.',
  },
  {
    id: 'l2',
    nama: 'Wira Suku Kata',
    penerangan: 'Berjaya menggabungkan suku kata terbuka menjadi perkataan.',
    ikon: '🎯',
    syarat: 'Selesaikan 3 aktiviti susun suku kata.',
  },
  {
    id: 'l3',
    nama: 'Bintang Ejaan',
    penerangan: 'Mendapat 3 bintang emas tanpa sebarang kesilapan.',
    ikon: '🏆',
    syarat: 'Capai markah penuh 100%.',
  },
  {
    id: 'l4',
    nama: 'Penulis Cilik Gemilang',
    penerangan: 'Menyurih dan menulis perkataan kemas di atas garisan KPM.',
    ikon: '✍️',
    syarat: 'Selesaikan latihan menulis garis 4.',
  },
  {
    id: 'l5',
    nama: 'Juara Pemulihan KPM',
    penerangan: 'Menguasai sekurang-kurangnya 5 kemahiran pemulihan berturut-turut.',
    ikon: '👑',
    syarat: 'Kumpul 50 bintang pembelajaran.',
  },
];

/**
 * Definisi Jenis Data Celik Minda Pemulihan Khas KPM
 * Berlandaskan Garis Panduan Program Pemulihan Khas Kementerian Pendidikan Malaysia
 */

export type TahapPenguasaanPBD = 'TP1' | 'TP2' | 'TP3' | 'TP4' | 'TP5' | 'TP6';

export interface Murid {
  id: string;
  nama: string;
  kelas: string;
  tahun: number;
  jantina: 'Lelaki' | 'Perempuan';
  avatar: string;
  tarikhDaftar: string;
  tahapSemasa: TahapPenguasaanPBD;
  bintangTerkumpul: number;
  lencanaDiterima: string[];
  catatanGuru?: string;
}

export type KategoriKemahiran = 
  | 'K1_HURUF_VOKAL' 
  | 'K2_HURUF_KONSONAN' 
  | 'K3_SUKUKATA_KV' 
  | 'K4_PERKATAAN_KVKV' 
  | 'K5_PERKATAAN_V_KVK' 
  | 'K6_PERKATAAN_KVK_KVK' 
  | 'K7_DIGRAF_DIFTONG';

export interface KemahiranInfo {
  id: KategoriKemahiran;
  kod: string;
  tajuk: string;
  penerangan: string;
  ikon: string;
  warnaTema: string;
}

export interface ItemAktiviti {
  id: string;
  perkataan: string;
  sukuKata: string[];
  huruf: string[];
  kategori: KategoriKemahiran;
  maksud: string;
  panduanFonik: string;
  petunjukSoalan: string;
  simbolSvg: string; // SVG data atau nama ikon ilustrasi
  tahapKesukaran: 1 | 2 | 3;
}

export interface PercubaanMurid {
  hurufDitarik: string;
  kedudukanBetul: boolean;
  masa: string;
}

export interface RekodPembelajaran {
  id: string;
  muridId: string;
  namaMurid: string;
  kelas: string;
  kemahiranId: KategoriKemahiran;
  namaKemahiran: string;
  perkataan: string;
  jenisAktiviti: 'SUSUN_SUKU_KATA' | 'SUSUN_HURUF' | 'TULIS_ASAS' | 'PADAN_GAMBAR';
  markah: number; // 0 - 100
  bilanganBintang: number; // 1 - 3
  dikuasai: boolean;
  bilanganPercubaan: number;
  kesilapanKerap: string[];
  tempohSaat: number;
  tarikhMasa: string; // ISO string
}

export interface LencanaPencapaian {
  id: string;
  nama: string;
  penerangan: string;
  ikon: string;
  syarat: string;
}

export type ModAktiviti = 
  | 'SUKU_KATA' 
  | 'SUSUN_HURUF' 
  | 'TULIS_ASAS' 
  | 'PADANAN' 
  | 'PAPAN_PEMUKA_GURU' 
  | 'SLIP_PELAPORAN';

/**
 * Enjin Audio & Sebutan Fonik Celik Minda Pemulihan Khas
 * Menggunakan Web Audio API dan Web Speech API yang beroperasi secara luar talian (offline).
 */

class SoundEngine {
  private audioCtx: AudioContext | null = null;

  private getContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioContextClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  // Bunyi petikan ketika seret atau sentuh kad
  playPop() {
    try {
      const ctx = this.getContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } catch {
      // Audio tidak disokong pada sesetengah penyemak imbas
    }
  }

  // Bunyi jawapan betul / kad tepat diletakkan
  playBetul() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;

      // Nota 1: G5 (784Hz)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(784, now);
      gain1.gain.setValueAtTime(0.2, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.15);

      // Nota 2: C6 (1046Hz)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(1046, now + 0.12);
      gain2.gain.setValueAtTime(0.25, now + 0.12);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.12);
      osc2.stop(now + 0.35);
    } catch {
      // Abaikan ralat audio
    }
  }

  // Bunyi ganjaran bintang
  playBintang() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6

      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);
        gain.gain.setValueAtTime(0.2, now + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.25);
      });
    } catch {
      // Abaikan ralat audio
    }
  }

  // Fanfare kemenangan syabas
  playKemenangan() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;
      const chords = [
        { f: 523.25, t: 0.0 }, // C5
        { f: 659.25, t: 0.12 }, // E5
        { f: 783.99, t: 0.24 }, // G5
        { f: 1046.50, t: 0.36 }, // C6
        { f: 1318.51, t: 0.52 }, // E6
      ];

      chords.forEach(({ f, t }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, now + t);
        gain.gain.setValueAtTime(0.22, now + t);
        gain.gain.exponentialRampToValueAtTime(0.001, now + t + 0.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + t);
        osc.stop(now + t + 0.5);
      });
    } catch {
      // Abaikan ralat audio
    }
  }

  // Nada lembut dorongan (Cuba Lagi)
  playCubaLagi() {
    try {
      const ctx = this.getContext();
      const now = ctx.currentTime;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(370, now);
      osc.frequency.linearRampToValueAtTime(290, now + 0.25);
      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.3);
    } catch {
      // Abaikan ralat audio
    }
  }

  // Sebutan suara bahasa Melayu menggunakan Web Speech API
  sebut(teks: string, kadar: number = 0.85) {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(teks);
    utterance.rate = kadar; // Kelajuan sedikit perlahan untuk murid pemulihan
    utterance.pitch = 1.15; // Suara lebih ceria dan ramah murid

    const voices = window.speechSynthesis.getVoices();
    // Cari suara Melayu Malaysia terlebih dahulu (ms-MY)
    const msVoice = voices.find(v => v.lang === 'ms-MY' || v.lang.startsWith('ms'));
    if (msVoice) {
      utterance.voice = msVoice;
    } else {
      // Fallback ke id-ID jika peranti tiada ms-MY untuk sistem sebutan vokal serupa
      const fallbackVoice = voices.find(v => v.lang === 'id-ID' || v.lang.startsWith('id'));
      if (fallbackVoice) {
        utterance.voice = fallbackVoice;
      }
    }

    window.speechSynthesis.speak(utterance);
  }

  // Eja fonik mengikut suku kata & sebutan BM
  ejaPerkataanFonik(sukuKataList: string[], perkataanPenuh: string) {
    const teksGabung = sukuKataList.join('... ') + '... ' + perkataanPenuh + '!';
    this.sebut(teksGabung, 0.75);
  }
}

export const bunyi = new SoundEngine();
